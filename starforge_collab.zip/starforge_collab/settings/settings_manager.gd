@tool
class_name StarForgeSettingsManager
extends RefCounted

## Manages project-wide settings for the StarForge Collab plugin.
## Registers configurations in Godot's ProjectSettings, and provides
## secure ConfigFile-based encrypted credential storage for sensitive tokens.

var event_bus: StarForgeEventBus = null

# Config keys constants (General settings)
const SETTING_GIT_PATH: String = "starforge_collab/general/git_path"
const SETTING_GIT_USERNAME: String = "starforge_collab/general/git_username"
const SETTING_DISCORD_SERVER_ID: String = "starforge_collab/general/discord_server_id"
const SETTING_DISCORD_CHAT_CHANNEL_ID: String = "starforge_collab/general/discord_chat_channel_id"
const SETTING_DISCORD_LOGS_CHANNEL_ID: String = "starforge_collab/general/discord_logs_channel_id"
const SETTING_AUTO_REFRESH_GIT: String = "starforge_collab/general/auto_refresh_git"
const SETTING_ENABLE_DISCORD_BRIDGE: String = "starforge_collab/general/enable_discord_bridge"

func _init(p_event_bus: StarForgeEventBus) -> void:
	event_bus = p_event_bus

## Registers settings under ProjectSettings and sets initial configuration states.
func register_settings() -> void:
	# active_tab (Default: 0)
	_register_project_setting(StarForgeConstants.SETTING_ACTIVE_TAB, 0, TYPE_INT, PROPERTY_HINT_NONE, "")
	
	# log_level (Default: 1 - INFO)
	_register_project_setting(StarForgeConstants.SETTING_LOG_LEVEL, StarForgeConstants.LogLevel.INFO, TYPE_INT, PROPERTY_HINT_ENUM, "Debug,Info,Warn,Error")
	
	# auto_refresh (Default: true)
	_register_project_setting(StarForgeConstants.SETTING_AUTO_REFRESH, true, TYPE_BOOL, PROPERTY_HINT_NONE, "")
	
	# notifications_enabled (Default: true)
	_register_project_setting(StarForgeConstants.SETTING_NOTIFICATIONS_ENABLED, true, TYPE_BOOL, PROPERTY_HINT_NONE, "")

	# Git Path (Default: "git")
	_register_project_setting(SETTING_GIT_PATH, "git", TYPE_STRING, PROPERTY_HINT_NONE, "")

	# Git Username (Default: "")
	_register_project_setting(SETTING_GIT_USERNAME, "", TYPE_STRING, PROPERTY_HINT_NONE, "")

	# Auto Refresh Git status (Default: true)
	_register_project_setting(SETTING_AUTO_REFRESH_GIT, true, TYPE_BOOL, PROPERTY_HINT_NONE, "")

	# Discord Server ID (Default: "")
	_register_project_setting(SETTING_DISCORD_SERVER_ID, "", TYPE_STRING, PROPERTY_HINT_NONE, "")

	# Discord Primary Chat Channel ID (Default: "")
	_register_project_setting(SETTING_DISCORD_CHAT_CHANNEL_ID, "", TYPE_STRING, PROPERTY_HINT_NONE, "")

	# Discord Logs Channel ID (Default: "")
	_register_project_setting(SETTING_DISCORD_LOGS_CHANNEL_ID, "", TYPE_STRING, PROPERTY_HINT_NONE, "")

	# Enable Discord Bridge (Default: false)
	_register_project_setting(SETTING_ENABLE_DISCORD_BRIDGE, false, TYPE_BOOL, PROPERTY_HINT_NONE, "")

	# Apply initial log level directly to logger
	var lvl: int = get_setting(StarForgeConstants.SETTING_LOG_LEVEL, StarForgeConstants.LogLevel.INFO) as int
	StarForgeLogger.set_level(lvl)
	StarForgeLogger.info("Project configurations registered successfully.", "SettingsManager")

## Purges registered project settings keys. Called on plugin deactivation.
func unregister_settings() -> void:
	var keys: Array[String] = [
		StarForgeConstants.SETTING_ACTIVE_TAB,
		StarForgeConstants.SETTING_LOG_LEVEL,
		StarForgeConstants.SETTING_AUTO_REFRESH,
		StarForgeConstants.SETTING_NOTIFICATIONS_ENABLED,
		SETTING_GIT_PATH,
		SETTING_GIT_USERNAME,
		SETTING_AUTO_REFRESH_GIT,
		SETTING_DISCORD_SERVER_ID,
		SETTING_DISCORD_CHAT_CHANNEL_ID,
		SETTING_DISCORD_LOGS_CHANNEL_ID,
		SETTING_ENABLE_DISCORD_BRIDGE
	]
	
	for key in keys:
		if ProjectSettings.has_setting(key):
			ProjectSettings.set_setting(key, null)
		
	ProjectSettings.save()
	StarForgeLogger.info("Project configurations unregistered from Editor.", "SettingsManager")

## Gets a setting's value, falling back to a default value if missing.
func get_setting(key: String, default: Variant = null) -> Variant:
	if ProjectSettings.has_setting(key):
		return ProjectSettings.get_setting(key)
	return default

## Sets a setting's value, saves ProjectSettings, and triggers EventBus signals.
func set_setting(key: String, value: Variant) -> void:
	ProjectSettings.set_setting(key, value)
	ProjectSettings.save()
	
	if key == StarForgeConstants.SETTING_LOG_LEVEL:
		StarForgeLogger.set_level(value as int)
		
	if event_bus != null:
		event_bus.setting_changed.emit(key, value)
		
	StarForgeLogger.info("Setting changed: %s = %s" % [key, str(value)], "SettingsManager")

# --- Encrypted Secrets API ---

## Retrieves a sensitive setting from encrypted storage.
func get_secret(key: String, default: String = "") -> String:
	var cf: ConfigFile = ConfigFile.new()
	var key_pass: String = OS.get_unique_id()
	var path: String = "user://starforge_secrets.dat"
	
	if FileAccess.file_exists(path):
		var err: Error = cf.load_encrypted_pass(path, key_pass)
		if err == OK:
			return cf.get_value("secrets", key, default) as String
			
	return default

## Encrypts and persists a sensitive value to local secure storage.
func set_secret(key: String, value: String) -> void:
	var cf: ConfigFile = ConfigFile.new()
	var key_pass: String = OS.get_unique_id()
	var path: String = "user://starforge_secrets.dat"
	
	# Pre-load existing secrets if file exists
	if FileAccess.file_exists(path):
		cf.load_encrypted_pass(path, key_pass)
		
	cf.set_value("secrets", key, value)
	var err: Error = cf.save_encrypted_pass(path, key_pass)
	if err != OK:
		StarForgeLogger.error("Failed to save encrypted secret. Error code: %d." % err, "SettingsManager")
	else:
		StarForgeLogger.info("Secret updated successfully: %s" % key, "SettingsManager")

func _register_project_setting(key: String, default_value: Variant, type: int, hint: int, hint_string: String) -> void:
	if not ProjectSettings.has_setting(key):
		ProjectSettings.set_setting(key, default_value)
		
	var info: Dictionary = {
		"name": key,
		"type": type,
		"hint": hint,
		"hint_string": hint_string
	}
	
	ProjectSettings.add_property_info(info)
	ProjectSettings.set_initial_value(key, default_value)
	ProjectSettings.set_as_basic(key, true)
	ProjectSettings.save()
