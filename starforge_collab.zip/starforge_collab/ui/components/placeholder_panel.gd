@tool
class_name StarForgePlaceholderPanel
extends MarginContainer

## Reusable placeholder component for uncompleted tabs or loading states.
## Redesigned to inherit from MarginContainer with a centered VBoxContainer
## to guarantee flawless text autowrapping and prevent layout inflation.

var icon_name: String = ""
var title: String = ""
var subtitle: String = ""

# Internal Control references
var icon_rect: TextureRect
var title_label: Label
var subtitle_label: Label

func _init(p_icon_name: String, p_title: String, p_subtitle: String = "") -> void:
	icon_name = p_icon_name
	title = p_title
	subtitle = p_subtitle
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL

func _ready() -> void:
	# Visual padding boundaries
	add_theme_constant_override("margin_left", 12)
	add_theme_constant_override("margin_top", 12)
	add_theme_constant_override("margin_right", 12)
	add_theme_constant_override("margin_bottom", 12)
	
	# Centered VBoxContainer vertically centering all children
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(vbox)
	
	# Icon container & TextureRect (horizontally centered)
	icon_rect = TextureRect.new()
	icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon_rect.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vbox.add_child(icon_rect)
	
	# Title Label (horizontally filling and smart-wrapping)
	title_label = Label.new()
	title_label.text = title
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_child(title_label)
	
	# Optional Subtitle Label (horizontally filling and smart-wrapping)
	if not subtitle.is_empty():
		subtitle_label = Label.new()
		subtitle_label.text = subtitle
		subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		subtitle_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		subtitle_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vbox.add_child(subtitle_label)
		
	# Listen for theme changes to automatically update styling when switching editor themes
	theme_changed.connect(_apply_theme)
	_apply_theme()

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	# Fetch theme properties directly from self
	if not icon_name.is_empty():
		var icon_texture: Texture2D = get_theme_icon(icon_name, "EditorIcons")
		if icon_texture:
			icon_rect.texture = icon_texture
			
	# Title Font & Sizes
	var title_font: Font = get_theme_font("bold", "EditorFonts")
	var title_font_size: int = get_theme_font_size("bold_size", "EditorFonts")
	
	title_label.add_theme_font_override("font", title_font)
	title_label.add_theme_font_size_override("font_size", title_font_size)
	
	# Discrete, premium gray colors for text matching the active editor theme
	var title_color: Color = get_theme_color("contrast_color_2", "Editor")
	title_label.add_theme_color_override("font_color", title_color)
	
	if subtitle_label:
		var sub_font: Font = get_theme_font("main", "EditorFonts")
		var sub_font_size: int = get_theme_font_size("main_size", "EditorFonts") - 1
		
		subtitle_label.add_theme_font_override("font", sub_font)
		subtitle_label.add_theme_font_size_override("font_size", sub_font_size)
		
		var sub_color: Color = get_theme_color("disabled_font_color", "Editor")
		subtitle_label.add_theme_color_override("font_color", sub_color)

	# Modulate the icon subtly with the editor's accent color to look elegant and professional
	var accent_color: Color = get_theme_color("accent_color", "Editor")
	icon_rect.self_modulate = accent_color * 0.6 + Color(0.4, 0.4, 0.4, 0.4)
