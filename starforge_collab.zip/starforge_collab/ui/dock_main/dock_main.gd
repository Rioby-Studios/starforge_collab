@tool
class_name StarForgeDockMain
extends VBoxContainer

## Main Dock panel UI for the StarForge Collab plugin.
## Constructs the interface dynamically and routes core manager references to tabs.

var event_bus: StarForgeEventBus = null
var settings_manager: StarForgeSettingsManager = null
var git_manager: StarForgeGitManager = null
var file_watcher: StarForgeFileWatcher = null
var activity_manager: StarForgeActivityManager = null
var bot_manager: StarForgeDiscordBotManager = null
var discord_bridge: StarForgeDiscordBridge = null

var tab_container: TabContainer
var settings_btn: Button

# Dynamic paths to tab scripts
const TAB_SCRIPTS: Dictionary = {
	0: "res://addons/starforge_collab/ui/tabs/tab_activity.gd",
	1: "res://addons/starforge_collab/ui/tabs/tab_git.gd",
	2: "res://addons/starforge_collab/ui/tabs/tab_team.gd",
	3: "res://addons/starforge_collab/ui/tabs/tab_chat.gd",
	4: "res://addons/starforge_collab/ui/tabs/tab_settings.gd"
}

func _init(
	p_event_bus: StarForgeEventBus, 
	p_settings_manager: StarForgeSettingsManager,
	p_git_manager: StarForgeGitManager = null,
	p_file_watcher: StarForgeFileWatcher = null,
	p_activity_manager: StarForgeActivityManager = null,
	p_bot_manager: StarForgeDiscordBotManager = null,
	p_discord_bridge: StarForgeDiscordBridge = null
) -> void:
	name = StarForgeConstants.PLUGIN_NAME
	event_bus = p_event_bus
	settings_manager = p_settings_manager
	git_manager = p_git_manager
	file_watcher = p_file_watcher
	activity_manager = p_activity_manager
	bot_manager = p_bot_manager
	discord_bridge = p_discord_bridge
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL

func _ready() -> void:
	# Root layout setup
	add_theme_constant_override("separation", 2)
	
	# --- Header MarginContainer ---
	var header_margin: MarginContainer = MarginContainer.new()
	header_margin.add_theme_constant_override("margin_left", 8)
	header_margin.add_theme_constant_override("margin_top", 6)
	header_margin.add_theme_constant_override("margin_right", 8)
	header_margin.add_theme_constant_override("margin_bottom", 6)
	header_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(header_margin)
	
	# Header Layout
	var header: HBoxContainer = HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	header_margin.add_child(header)
	
	# Brand Forge Icon
	var brand_icon: TextureRect = TextureRect.new()
	brand_icon.name = "BrandIcon"
	brand_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	brand_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(brand_icon)
	
	# Brand Label
	var brand_title: Label = Label.new()
	brand_title.name = "BrandTitle"
	brand_title.text = StarForgeConstants.PLUGIN_NAME
	brand_title.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(brand_title)
	
	# Dynamic Spacer
	var spacer: Control = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(spacer)
	
	# Settings Button (Engrenagem)
	settings_btn = Button.new()
	settings_btn.flat = true
	settings_btn.tooltip_text = "StarForge Settings"
	settings_btn.focus_mode = Control.FOCUS_NONE
	header.add_child(settings_btn)
	settings_btn.pressed.connect(_on_settings_pressed)
	
	# Subtle HSeparator to delineate header from content
	var sep: HSeparator = HSeparator.new()
	add_child(sep)
	
	# --- TabContainer Layout ---
	tab_container = TabContainer.new()
	tab_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tab_container.clip_tabs = true
	add_child(tab_container)
	
	# Instantiate and add tabs programmatically
	_setup_tabs()
	
	# Restore last active tab to maintain editor state
	if settings_manager != null:
		var last_tab: int = settings_manager.get_setting(StarForgeConstants.SETTING_ACTIVE_TAB, 0) as int
		if last_tab >= 0 and last_tab < tab_container.get_child_count():
			tab_container.current_tab = last_tab
			
	# Connect signals
	tab_container.tab_changed.connect(_on_tab_changed)
	
	# Initial theme application and connection
	theme_changed.connect(_apply_theme)
	_apply_theme()

func _setup_tabs() -> void:
	var tab_names: Array[String] = ["Activity", "Git", "Team", "Chat", "Settings"]
	
	for i in range(5):
		var path: String = TAB_SCRIPTS[i]
		var tab_script: GDScript = load(path) as GDScript
		if tab_script:
			var tab_instance: Control = tab_script.new() as Control
			tab_instance.name = tab_names[i]
			tab_container.add_child(tab_instance)
			
			# Setup tabs dynamically with their required dependencies
			if tab_instance.has_method("setup"):
				match i:
					0: # Activity Feed
						tab_instance.call("setup", event_bus, activity_manager)
					1: # Git UI
						tab_instance.call("setup", event_bus, git_manager)
					3: # Chat Tab
						tab_instance.call("setup", event_bus, discord_bridge, bot_manager)
					4: # Settings Tab
						tab_instance.call("setup", event_bus, settings_manager, bot_manager, discord_bridge)
		else:
			StarForgeLogger.error("Failed to load tab script: %s" % path, "DockMain")

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	# Brand logo styling using native AssetLib icon
	var brand_icon_node: TextureRect = find_child("BrandIcon", true, false) as TextureRect
	if brand_icon_node:
		var logo_tex: Texture2D = get_theme_icon("AssetLib", "EditorIcons")
		brand_icon_node.texture = logo_tex
		var accent_color: Color = get_theme_color("accent_color", "Editor")
		brand_icon_node.self_modulate = accent_color
		
	# Brand title typography
	var brand_title_node: Label = find_child("BrandTitle", true, false) as Label
	if brand_title_node:
		brand_title_node.add_theme_font_override("font", get_theme_font("bold", "EditorFonts"))
		brand_title_node.add_theme_font_size_override("font_size", get_theme_font_size("bold_size", "EditorFonts"))
		brand_title_node.add_theme_color_override("font_color", get_theme_color("contrast_color_1", "Editor"))
		
	# Settings button icon styling
	if settings_btn:
		settings_btn.icon = get_theme_icon("EditorSettings", "EditorIcons")
		
	# Tab icons assignment from EditorIcons
	var tab_icons: Array[String] = ["Notification", "VcsBranches", "Groups", "RichTextEffect", "EditorSettings"]
	for i in range(tab_container.get_child_count()):
		var icon_tex: Texture2D = get_theme_icon(tab_icons[i], "EditorIcons")
		if icon_tex:
			tab_container.set_tab_icon(i, icon_tex)

func _on_tab_changed(tab_idx: int) -> void:
	if settings_manager != null:
		settings_manager.set_setting(StarForgeConstants.SETTING_ACTIVE_TAB, tab_idx)
		
	if event_bus != null:
		var tab_name: String = tab_container.get_tab_title(tab_idx)
		event_bus.tab_changed.emit(tab_name)

func _on_settings_pressed() -> void:
	# Instantly direct user to Settings tab (index 4)
	if tab_container:
		tab_container.current_tab = 4
