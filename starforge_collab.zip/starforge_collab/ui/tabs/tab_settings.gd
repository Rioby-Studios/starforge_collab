@tool
extends ScrollContainer

## Settings UI Tab for StarForge Collab.
## Handles project preferences, secure bot token configuration,
## and background Discord bot process lifecycles.

var event_bus: StarForgeEventBus = null
var settings_manager: StarForgeSettingsManager = null
var bot_manager: StarForgeDiscordBotManager = null
var discord_bridge: StarForgeDiscordBridge = null

# UI Control References
var git_path_input: LineEdit
var git_username_input: LineEdit
var git_token_input: LineEdit
var auto_refresh_git_input: CheckBox
var token_input: LineEdit
var server_id_input: LineEdit
var chat_channel_input: LineEdit
var logs_channel_input: LineEdit
var enable_bridge_input: CheckBox

var log_level_input: OptionButton
var notifications_input: CheckBox

var toggle_bot_btn: Button
var led_rect: ColorRect
var bot_status_label: Label
var bot_error_label: Label

var save_btn: Button
var feedback_label: Label

var status_timer: Timer

## Dynamic binding of systems passed down from the plugin manager.
func setup(p_event_bus, p_settings, p_bot_manager, p_bridge) -> void:
	event_bus = p_event_bus
	settings_manager = p_settings
	bot_manager = p_bot_manager
	discord_bridge = p_bridge

func _ready() -> void:
	# Enforce scroll properties to ensure flawless resizing bounds
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var margin_container: MarginContainer = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 12)
	margin_container.add_theme_constant_override("margin_top", 12)
	margin_container.add_theme_constant_override("margin_right", 12)
	margin_container.add_theme_constant_override("margin_bottom", 12)
	margin_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(margin_container)
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 15)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.add_child(vbox)
	
	# --- Section: Git Configs ---
	var git_section: VBoxContainer = _create_section(vbox, "Configurações do Git")
	
	var git_path_row: HBoxContainer = _create_row(git_section, "Caminho do Git:")
	git_path_input = LineEdit.new()
	git_path_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	git_path_row.add_child(git_path_input)
	
	var git_user_row: HBoxContainer = _create_row(git_section, "Usuário do Git:")
	git_username_input = LineEdit.new()
	git_username_input.placeholder_text = "Usuário do repositório Git"
	git_username_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	git_user_row.add_child(git_username_input)
	
	var git_token_row: HBoxContainer = _create_row(git_section, "Token / Senha Git:")
	var git_token_hbox: HBoxContainer = HBoxContainer.new()
	git_token_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	git_token_row.add_child(git_token_hbox)
	
	git_token_input = LineEdit.new()
	git_token_input.secret = true
	git_token_input.placeholder_text = "Token de Acesso Pessoal (PAT) ou senha"
	git_token_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	git_token_hbox.add_child(git_token_input)
	
	var git_eye_btn: Button = Button.new()
	git_eye_btn.flat = true
	git_eye_btn.focus_mode = Control.FOCUS_NONE
	git_token_hbox.add_child(git_eye_btn)
	git_eye_btn.pressed.connect(func():
		git_token_input.secret = not git_token_input.secret
		_update_eye_icon(git_eye_btn, git_token_input.secret)
	)
	
	var refresh_git_row: HBoxContainer = _create_row(git_section, "")
	auto_refresh_git_input = CheckBox.new()
	auto_refresh_git_input.text = "Auto Refresh do Status Git"
	auto_refresh_git_input.focus_mode = Control.FOCUS_NONE
	refresh_git_row.add_child(auto_refresh_git_input)
	
	# --- Section: Discord Bot Configs ---
	var discord_section: VBoxContainer = _create_section(vbox, "Integração Discord Bot (Local)")
	
	var token_row: HBoxContainer = _create_row(discord_section, "Bot Token:")
	var token_hbox: HBoxContainer = HBoxContainer.new()
	token_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	token_row.add_child(token_hbox)
	
	token_input = LineEdit.new()
	token_input.secret = true
	token_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	token_hbox.add_child(token_input)
	
	var eye_btn: Button = Button.new()
	eye_btn.flat = true
	eye_btn.focus_mode = Control.FOCUS_NONE
	token_hbox.add_child(eye_btn)
	eye_btn.pressed.connect(func():
		token_input.secret = not token_input.secret
		_update_eye_icon(eye_btn, token_input.secret)
	)
	
	var server_row: HBoxContainer = _create_row(discord_section, "Server ID:")
	server_id_input = LineEdit.new()
	server_id_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	server_row.add_child(server_id_input)
	
	var chat_channel_row: HBoxContainer = _create_row(discord_section, "Chat Channel ID:")
	chat_channel_input = LineEdit.new()
	chat_channel_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_channel_row.add_child(chat_channel_input)
	
	var logs_channel_row: HBoxContainer = _create_row(discord_section, "Logs Channel ID:")
	logs_channel_input = LineEdit.new()
	logs_channel_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	logs_channel_row.add_child(logs_channel_input)
	
	var bridge_toggle_row: HBoxContainer = _create_row(discord_section, "")
	enable_bridge_input = CheckBox.new()
	enable_bridge_input.text = "Ativar Discord Bridge"
	enable_bridge_input.focus_mode = Control.FOCUS_NONE
	bridge_toggle_row.add_child(enable_bridge_input)
	
	# Discord Bot Local Process Control Panel
	var bot_ctrl_panel: VBoxContainer = VBoxContainer.new()
	bot_ctrl_panel.add_theme_constant_override("separation", 8)
	bot_ctrl_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	discord_section.add_child(bot_ctrl_panel)
	
	var status_container: HBoxContainer = HBoxContainer.new()
	status_container.add_theme_constant_override("separation", 6)
	status_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bot_ctrl_panel.add_child(status_container)
	
	# Rounded LED Status indicator
	var led_margin: CenterContainer = CenterContainer.new()
	status_container.add_child(led_margin)
	led_rect = ColorRect.new()
	led_rect.custom_minimum_size = Vector2(8, 8)
	led_rect.color = Color.RED
	led_margin.add_child(led_rect)
	
	bot_status_label = Label.new()
	bot_status_label.text = "Status: Desconectado"
	status_container.add_child(bot_status_label)
	
	toggle_bot_btn = Button.new()
	toggle_bot_btn.text = "Ligar Bot"
	toggle_bot_btn.focus_mode = Control.FOCUS_NONE
	toggle_bot_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bot_ctrl_panel.add_child(toggle_bot_btn)
	toggle_bot_btn.pressed.connect(_on_toggle_bot_pressed)
	
	bot_error_label = Label.new()
	bot_error_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bot_error_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bot_error_label.visible = false
	bot_ctrl_panel.add_child(bot_error_label)
	
	# --- Section: General preferences ---
	var general_section: VBoxContainer = _create_section(vbox, "Preferências Gerais")
	
	var log_row: HBoxContainer = _create_row(general_section, "Nível de Log:")
	log_level_input = OptionButton.new()
	log_level_input.add_item("Debug", 0)
	log_level_input.add_item("Info", 1)
	log_level_input.add_item("Warn", 2)
	log_level_input.add_item("Error", 3)
	log_level_input.focus_mode = Control.FOCUS_NONE
	log_row.add_child(log_level_input)
	
	var notif_row: HBoxContainer = _create_row(general_section, "")
	notifications_input = CheckBox.new()
	notifications_input.text = "Ativar Notificações no Editor"
	notifications_input.focus_mode = Control.FOCUS_NONE
	notif_row.add_child(notifications_input)
	
	# --- Footer Controls ---
	var footer: HBoxContainer = HBoxContainer.new()
	footer.add_theme_constant_override("separation", 10)
	vbox.add_child(footer)
	
	feedback_label = Label.new()
	feedback_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(feedback_label)
	
	save_btn = Button.new()
	save_btn.text = "Salvar Configurações"
	save_btn.focus_mode = Control.FOCUS_NONE
	footer.add_child(save_btn)
	save_btn.pressed.connect(_on_save_pressed)
	
	# Initial settings load
	_load_ui_settings()
	_update_eye_icon(eye_btn, true)
	_update_eye_icon(git_eye_btn, true)
	
	# Timer to update bot connection status dynamically
	status_timer = Timer.new()
	status_timer.wait_time = 1.5
	add_child(status_timer)
	status_timer.timeout.connect(_update_bot_status_ui)
	status_timer.start()
	
	theme_changed.connect(_apply_theme)
	_apply_theme()

func _create_section(parent: Node, title_text: String) -> VBoxContainer:
	var container: VBoxContainer = VBoxContainer.new()
	container.add_theme_constant_override("separation", 6)
	container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(container)
	
	var title_lbl: Label = Label.new()
	title_lbl.text = title_text
	title_lbl.name = "SectionTitle"
	container.add_child(title_lbl)
	
	var sep: HSeparator = HSeparator.new()
	container.add_child(sep)
	
	return container

func _create_row(parent: Node, label_text: String) -> HBoxContainer:
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(row)
	
	if not label_text.is_empty():
		var row_lbl: Label = Label.new()
		row_lbl.text = label_text
		row_lbl.custom_minimum_size = Vector2(110, 0)
		row_lbl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(row_lbl)
		
	return row

func _update_eye_icon(btn: Button, is_secret: bool) -> void:
	var icon_name: String = "GuiVisibilityHidden" if is_secret else "GuiVisibilityVisible"
	var icon: Texture2D = get_theme_icon(icon_name, "EditorIcons")
	if icon:
		btn.icon = icon

func _load_ui_settings() -> void:
	if settings_manager == null:
		return
		
	git_path_input.text = settings_manager.get_setting(StarForgeSettingsManager.SETTING_GIT_PATH, "git")
	auto_refresh_git_input.button_pressed = settings_manager.get_setting(StarForgeSettingsManager.SETTING_AUTO_REFRESH_GIT, true)
	
	server_id_input.text = settings_manager.get_setting(StarForgeSettingsManager.SETTING_DISCORD_SERVER_ID, "")
	chat_channel_input.text = settings_manager.get_setting(StarForgeSettingsManager.SETTING_DISCORD_CHAT_CHANNEL_ID, "")
	logs_channel_input.text = settings_manager.get_setting(StarForgeSettingsManager.SETTING_DISCORD_LOGS_CHANNEL_ID, "")
	enable_bridge_input.button_pressed = settings_manager.get_setting(StarForgeSettingsManager.SETTING_ENABLE_DISCORD_BRIDGE, false)
	
	# Fetch decrypted bot token securely
	token_input.text = settings_manager.get_secret("discord_bot_token", "")
	
	var lvl: int = settings_manager.get_setting(StarForgeConstants.SETTING_LOG_LEVEL, 1) as int
	log_level_input.selected = lvl
	notifications_input.button_pressed = settings_manager.get_setting(StarForgeConstants.SETTING_NOTIFICATIONS_ENABLED, true)
	
	_update_bot_status_ui()

func _on_save_pressed() -> void:
	if settings_manager == null:
		return
		
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_GIT_PATH, git_path_input.text.strip_edges())
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_AUTO_REFRESH_GIT, auto_refresh_git_input.button_pressed)
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_DISCORD_SERVER_ID, server_id_input.text.strip_edges())
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_DISCORD_CHAT_CHANNEL_ID, chat_channel_input.text.strip_edges())
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_DISCORD_LOGS_CHANNEL_ID, logs_channel_input.text.strip_edges())
	settings_manager.set_setting(StarForgeSettingsManager.SETTING_ENABLE_DISCORD_BRIDGE, enable_bridge_input.button_pressed)
	
	# Encrypt and save token
	settings_manager.set_secret("discord_bot_token", token_input.text.strip_edges())
	
	settings_manager.set_setting(StarForgeConstants.SETTING_LOG_LEVEL, log_level_input.selected)
	settings_manager.set_setting(StarForgeConstants.SETTING_NOTIFICATIONS_ENABLED, notifications_input.button_pressed)
	
	feedback_label.text = "Configurações salvas com sucesso!"
	feedback_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
	
	get_tree().create_timer(2.0).timeout.connect(func():
		feedback_label.text = ""
	)

func _on_toggle_bot_pressed() -> void:
	if bot_manager == null or discord_bridge == null:
		return
		
	if bot_manager.is_bot_running():
		# Disconnect bridge gracefully
		discord_bridge.stop_bridge()
		toggle_bot_btn.text = "Ligar Bot"
		StarForgeLogger.info("Discord Bot stop requested via UI.", "SettingsUI")
	else:
		# Save UI fields first to capture latest token
		_on_save_pressed()
		
		var token: String = token_input.text.strip_edges()
		var chan_str: String = chat_channel_input.text.strip_edges()
		var log_chan_str: String = logs_channel_input.text.strip_edges()
		
		if token.is_empty() or chan_str.is_empty():
			feedback_label.text = "Erro: Token e Chat Channel ID são obrigatórios!"
			feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))
			return
			
		var channel_id: int = chan_str.to_int()
		var log_channel_id: int = log_chan_str.to_int() if not log_chan_str.is_empty() else 0
		
		var success: bool = bot_manager.start_bot(token, channel_id, log_channel_id)
		if success:
			discord_bridge.start_bridge()
			toggle_bot_btn.text = "Desligar Bot"
			StarForgeLogger.info("Discord Bot start requested via UI.", "SettingsUI")
		else:
			feedback_label.text = "Erro ao iniciar o processo Python!"
			feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))

func _update_bot_status_ui() -> void:
	if bot_manager == null:
		led_rect.color = Color.RED
		bot_status_label.text = "Status: Desconectado"
		toggle_bot_btn.text = "Ligar Bot"
		bot_error_label.visible = false
		return
		
	var is_running: bool = bot_manager.is_bot_running()
	if is_running:
		if discord_bridge != null and discord_bridge.is_connected_to_bot:
			led_rect.color = Color.GREEN
			bot_status_label.text = "Status: Online"
			bot_error_label.visible = false
		else:
			led_rect.color = Color.YELLOW
			bot_status_label.text = "Status: Conectando..."
			
			var err: String = bot_manager.get_last_bot_error()
			if not err.is_empty():
				bot_error_label.text = "Aviso/Erro:\n" + err
				bot_error_label.visible = true
				bot_error_label.add_theme_color_override("font_color", get_theme_color("warning_color", "Editor"))
			else:
				bot_error_label.visible = false
		toggle_bot_btn.text = "Desligar Bot"
	else:
		led_rect.color = Color.RED
		bot_status_label.text = "Status: Desconectado"
		toggle_bot_btn.text = "Ligar Bot"
		
		var err: String = bot_manager.get_last_bot_error()
		if not err.is_empty():
			bot_error_label.text = "Erro:\n" + err
			bot_error_label.visible = true
			bot_error_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))
		else:
			bot_error_label.visible = false

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	var bold_font: Font = get_theme_font("bold", "EditorFonts")
	var bold_size: int = get_theme_font_size("bold_size", "EditorFonts")
	var normal_color: Color = get_theme_color("contrast_color_1", "Editor")
	
	for child in find_children("", "Label", true, false):
		if child.name == "SectionTitle":
			child.add_theme_font_override("font", bold_font)
			child.add_theme_font_size_override("font_size", bold_size)
			child.add_theme_color_override("font_color", normal_color)
