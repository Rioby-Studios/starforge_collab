@tool
extends ScrollContainer

## Team Presence Tab for StarForge Collab.
## Now inherits from ScrollContainer with horizontal scroll disabled to prevent editor layout inflation.

func _ready() -> void:
	# Enforce layout bounds to preserve Godot Editor splitters
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	# Content padding container
	var margin_container: MarginContainer = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 12)
	margin_container.add_theme_constant_override("margin_top", 12)
	margin_container.add_theme_constant_override("margin_right", 12)
	margin_container.add_theme_constant_override("margin_bottom", 12)
	margin_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(margin_container)
	
	# Instantiate placeholder panel
	var placeholder: StarForgePlaceholderPanel = StarForgePlaceholderPanel.new(
		"Groups",
		"Team Workspace Coming Soon",
		"See who is online and what scenes they are working on."
	)
	margin_container.add_child(placeholder)
