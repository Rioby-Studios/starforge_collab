@tool
extends ScrollContainer

## Live Chat UI Tab for StarForge Collab.
## Renders chat communications in classic IRC style, featuring themed BBCode coloring,
## autowrapping, and automatic HTTP local bot connection checking.

var event_bus: StarForgeEventBus = null
var discord_bridge: StarForgeDiscordBridge = null
var bot_manager: StarForgeDiscordBotManager = null

var messages_vbox: VBoxContainer
var message_input: LineEdit
var send_btn: Button
var status_banner: Label
var placeholder_lbl: Label

## Dynamic binding of systems passed down from the plugin manager.
func setup(p_event_bus, p_bridge, p_bot_manager) -> void:
	event_bus = p_event_bus
	discord_bridge = p_bridge
	bot_manager = p_bot_manager
	
	if event_bus != null:
		event_bus.connect_event("message_received", _on_message_received)

func _ready() -> void:
	# Enforce scroll properties to ensure layout safety inside editor docks
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var margin_container: MarginContainer = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 12)
	margin_container.add_theme_constant_override("margin_top", 12)
	margin_container.add_theme_constant_override("margin_right", 12)
	margin_container.add_theme_constant_override("margin_bottom", 12)
	margin_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(margin_container)
	
	var main_vbox: VBoxContainer = VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", 8)
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin_container.add_child(main_vbox)
	
	# Status Banner
	status_banner = Label.new()
	status_banner.text = "Discord Bridge: Desconectado"
	status_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_banner.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	main_vbox.add_child(status_banner)
	
	var sep: HSeparator = HSeparator.new()
	main_vbox.add_child(sep)
	
	# Scrollable chat logs view
	var chat_scroll: ScrollContainer = ScrollContainer.new()
	chat_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	chat_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	main_vbox.add_child(chat_scroll)
	
	messages_vbox = VBoxContainer.new()
	messages_vbox.add_theme_constant_override("separation", 4)
	messages_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	messages_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_scroll.add_child(messages_vbox)
	
	placeholder_lbl = Label.new()
	placeholder_lbl.text = "Conecte o bot do Discord para começar a conversar no workspace."
	placeholder_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	placeholder_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	placeholder_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	messages_vbox.add_child(placeholder_lbl)
	
	var input_sep: HSeparator = HSeparator.new()
	main_vbox.add_child(input_sep)
	
	# Footer input row
	var input_hbox: HBoxContainer = HBoxContainer.new()
	input_hbox.add_theme_constant_override("separation", 6)
	input_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(input_hbox)
	
	message_input = LineEdit.new()
	message_input.placeholder_text = "Digite sua mensagem..."
	message_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input_hbox.add_child(message_input)
	message_input.text_submitted.connect(_on_message_submitted)
	
	send_btn = Button.new()
	send_btn.text = "Enviar"
	send_btn.flat = true
	send_btn.focus_mode = Control.FOCUS_NONE
	input_hbox.add_child(send_btn)
	send_btn.pressed.connect(func(): _on_message_submitted(message_input.text))
	
	# Polling Timer for status
	var status_timer: Timer = Timer.new()
	status_timer.wait_time = 2.0
	add_child(status_timer)
	status_timer.timeout.connect(_update_status_banner)
	status_timer.start()
	
	_update_status_banner()
	theme_changed.connect(_apply_theme)
	_apply_theme()

func _update_status_banner() -> void:
	if discord_bridge == null or bot_manager == null:
		status_banner.text = "Discord Bridge: Inativo"
		status_banner.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
		message_input.editable = false
		send_btn.disabled = true
		return
		
	var is_running: bool = bot_manager.is_bot_running()
	if is_running:
		if discord_bridge.is_connected_to_bot:
			status_banner.text = "Discord Bridge: Online"
			status_banner.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
			message_input.editable = true
			send_btn.disabled = false
			if messages_vbox.get_child_count() > 1:
				placeholder_lbl.visible = false
		else:
			status_banner.text = "Discord Bridge: Conectando com Bot local..."
			status_banner.add_theme_color_override("font_color", get_theme_color("warning_color", "Editor"))
			message_input.editable = false
			send_btn.disabled = true
	else:
		status_banner.text = "Discord Bridge: Desconectado (Ligue o Bot em Configurações)"
		status_banner.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
		message_input.editable = false
		send_btn.disabled = true

func _on_message_submitted(text: String) -> void:
	text = text.strip_edges()
	if text.is_empty():
		return
		
	if discord_bridge == null or not discord_bridge.is_connected_to_bot:
		return
		
	# Post to the local discord bot REST server
	discord_bridge.send_chat_message(text)
	
	# Append locally instantly for snappy feedback
	var local_msg: Dictionary = {
		"author": "Você",
		"text": text,
		"timestamp": Time.get_unix_time_from_system() as int
	}
	_on_message_received(local_msg)
	
	message_input.text = ""

func _on_message_received(msg: Dictionary) -> void:
	if placeholder_lbl.visible:
		placeholder_lbl.visible = false
		
	var author: String = msg.get("author", "Desconhecido")
	var text: String = msg.get("text", "")
	var timestamp: int = msg.get("timestamp", 0) as int
	
	var time_str: String = "00:00:00"
	if timestamp > 0:
		var time_dict: Dictionary = Time.get_time_dict_from_unix_time(timestamp)
		time_str = "%02d:%02d:%02d" % [time_dict.hour, time_dict.minute, time_dict.second]
		
	# Themed color conversions
	var time_color: String = get_theme_color("disabled_font_color", "Editor").to_html(false)
	var author_color: String = get_theme_color("contrast_color_1", "Editor").to_html(false)
	
	if author == "Você":
		author_color = get_theme_color("accent_color", "Editor").to_html(false)
		
	# Create premium BBCode colored RichTextLabel in IRC format
	var irc_msg: RichTextLabel = RichTextLabel.new()
	irc_msg.bbcode_enabled = true
	irc_msg.fit_content = true
	irc_msg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	irc_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	irc_msg.text = "[color=#%s][%s][/color] [b][color=#%s]<%s>[/color][/b]: %s" % [time_color, time_str, author_color, author, text]
	messages_vbox.add_child(irc_msg)

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	if placeholder_lbl:
		placeholder_lbl.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
		
	# Format status banner to be sutilly bold
	if status_banner:
		status_banner.add_theme_font_override("font", get_theme_font("bold", "EditorFonts"))
