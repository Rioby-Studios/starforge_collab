@tool
extends ScrollContainer

## Activity UI Tab for StarForge Collab.
## Renders workspace logs in a hybrid visual card feed or a technical terminal view.

var event_bus: StarForgeEventBus = null
var activity_manager: StarForgeActivityManager = null

var is_technical_mode: bool = false

# UI references
var mode_btn: Button
var visual_scroll: ScrollContainer
var visual_vbox: VBoxContainer
var placeholder_lbl: Label

var terminal_scroll: ScrollContainer
var terminal_rtl: RichTextLabel

## Binds EventBus and ActivityManager dependencies passed from the dock panel.
func setup(p_event_bus: StarForgeEventBus, p_activity_manager: StarForgeActivityManager) -> void:
	event_bus = p_event_bus
	activity_manager = p_activity_manager
	
	if event_bus != null:
		event_bus.connect_event("activity_created", _on_activity_created)

func _ready() -> void:
	# Enforce scroll properties to ensure layout safety inside editor docks
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var margin_container: MarginContainer = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 12)
	margin_container.add_theme_constant_override("margin_top", 12)
	margin_container.add_theme_constant_override("margin_right", 12)
	margin_container.add_theme_constant_override("margin_bottom", 12)
	margin_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(margin_container)
	
	var main_vbox: VBoxContainer = VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", 10)
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin_container.add_child(main_vbox)
	
	# --- Header Row ---
	var header_hbox: HBoxContainer = HBoxContainer.new()
	header_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(header_hbox)
	
	var header_lbl: Label = Label.new()
	header_lbl.text = "Feed de Atividades"
	header_lbl.name = "HeaderTitle"
	header_hbox.add_child(header_lbl)
	
	var spacer: Control = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_hbox.add_child(spacer)
	
	mode_btn = Button.new()
	mode_btn.text = "Console"
	mode_btn.flat = true
	mode_btn.focus_mode = Control.FOCUS_NONE
	header_hbox.add_child(mode_btn)
	mode_btn.pressed.connect(_on_mode_toggled)
	
	var sep: HSeparator = HSeparator.new()
	main_vbox.add_child(sep)
	
	# --- Visual Feed Layout ---
	visual_scroll = ScrollContainer.new()
	visual_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	visual_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	visual_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	visual_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	main_vbox.add_child(visual_scroll)
	
	visual_vbox = VBoxContainer.new()
	visual_vbox.add_theme_constant_override("separation", 8)
	visual_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	visual_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	visual_scroll.add_child(visual_vbox)
	
	placeholder_lbl = Label.new()
	placeholder_lbl.text = "Nenhuma atividade registrada ainda."
	placeholder_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	placeholder_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	placeholder_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	visual_vbox.add_child(placeholder_lbl)
	
	# --- Technical Terminal Layout ---
	terminal_scroll = ScrollContainer.new()
	terminal_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	terminal_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	terminal_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	terminal_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	terminal_scroll.visible = false
	main_vbox.add_child(terminal_scroll)
	
	terminal_rtl = RichTextLabel.new()
	terminal_rtl.bbcode_enabled = true
	terminal_rtl.fit_content = true
	terminal_rtl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	terminal_rtl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	terminal_scroll.add_child(terminal_rtl)
	
	# Initial display refresh
	refresh_activity_view()
	
	theme_changed.connect(_apply_theme)
	_apply_theme()

func _on_mode_toggled() -> void:
	is_technical_mode = not is_technical_mode
	if is_technical_mode:
		mode_btn.text = "Visual"
		visual_scroll.visible = false
		terminal_scroll.visible = true
	else:
		mode_btn.text = "Console"
		visual_scroll.visible = true
		terminal_scroll.visible = false
		
	refresh_activity_view()

func _on_activity_created(_data: Dictionary) -> void:
	refresh_activity_view()

func refresh_activity_view() -> void:
	if activity_manager == null:
		return
		
	var list: Array = activity_manager.get_activities()
	
	_clear_visual_feed()
	if list.is_empty():
		placeholder_lbl.visible = true
	else:
		placeholder_lbl.visible = false
		for event in list:
			_create_activity_card(event)
			
	_update_technical_terminal(list)

func _clear_visual_feed() -> void:
	for child in visual_vbox.get_children():
		if child != placeholder_lbl:
			child.queue_free()

func _create_activity_card(event: StarForgeActivityEvent) -> void:
	var card: HBoxContainer = HBoxContainer.new()
	card.add_theme_constant_override("separation", 10)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	visual_vbox.add_child(card)
	
	# Determine dynamic status icons and mods
	var icon_tex: Texture2D = get_theme_icon("Node", "EditorIcons")
	var icon_color: Color = get_theme_color("contrast_color_2", "Editor")
	
	match event.type:
		"git_commit":
			icon_tex = get_theme_icon("VcsBranches", "EditorIcons")
			icon_color = get_theme_color("accent_color", "Editor")
		"git_push", "git_pull":
			icon_tex = get_theme_icon("Loop", "EditorIcons")
			icon_color = get_theme_color("accent_color", "Editor")
		"file_changed":
			icon_tex = get_theme_icon("File", "EditorIcons")
			icon_color = get_theme_color("warning_color", "Editor")
		"bot_connected":
			icon_tex = get_theme_icon("AssetLib", "EditorIcons")
			icon_color = get_theme_color("success_color", "Editor")
		"chat_message":
			icon_tex = get_theme_icon("RichTextEffect", "EditorIcons")
			icon_color = get_theme_color("contrast_color_1", "Editor")
			
	var tex_rect: TextureRect = TextureRect.new()
	tex_rect.texture = icon_tex
	tex_rect.self_modulate = icon_color
	tex_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex_rect.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	card.add_child(tex_rect)
	
	var text_vbox: VBoxContainer = VBoxContainer.new()
	text_vbox.add_theme_constant_override("separation", 2)
	text_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.add_child(text_vbox)
	
	# Title row (User + Time)
	var title_row: HBoxContainer = HBoxContainer.new()
	title_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_vbox.add_child(title_row)
	
	var user_lbl: Label = Label.new()
	user_lbl.text = event.user
	user_lbl.add_theme_font_override("font", get_theme_font("bold", "EditorFonts"))
	title_row.add_child(user_lbl)
	
	var time_lbl: Label = Label.new()
	var time_dict: Dictionary = Time.get_time_dict_from_unix_time(event.timestamp)
	time_lbl.text = " • %02d:%02d" % [time_dict.hour, time_dict.minute]
	time_lbl.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
	time_lbl.add_theme_font_size_override("font_size", get_theme_font_size("main_size", "EditorFonts") - 1)
	title_row.add_child(time_lbl)
	
	var desc_lbl: Label = Label.new()
	desc_lbl.text = event.description
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_vbox.add_child(desc_lbl)

func _update_technical_terminal(list: Array) -> void:
	terminal_rtl.clear()
	
	var text_lines: Array = []
	var reversed: Array = list.duplicate()
	reversed.reverse() # Oldest to newest at bottom
	
	for element in reversed:
		var event: StarForgeActivityEvent = element as StarForgeActivityEvent
		var time_dict: Dictionary = Time.get_time_dict_from_unix_time(event.timestamp)
		var time_str: String = "%02d:%02d:%02d" % [time_dict.hour, time_dict.minute, time_dict.second]
		
		var tag: String = "SYS"
		var tag_color: String = get_theme_color("disabled_font_color", "Editor").to_html(false)
		
		match event.type:
			"git_commit", "git_push", "git_pull":
				tag = "VCS"
				tag_color = get_theme_color("accent_color", "Editor").to_html(false)
			"file_changed":
				tag = "FILES"
				tag_color = get_theme_color("warning_color", "Editor").to_html(false)
			"bot_connected":
				tag = "BRIDGE"
				tag_color = get_theme_color("success_color", "Editor").to_html(false)
			"chat_message":
				tag = "CHAT"
				tag_color = get_theme_color("contrast_color_1", "Editor").to_html(false)
				
		var line: String = "[color=#A5A5A5][%s][/color] [b][color=#%s][%s][/color][/b] %s" % [time_str, tag_color, tag, event.description]
		text_lines.append(line)
		
	terminal_rtl.text = "\n".join(text_lines)

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	var bold_font: Font = get_theme_font("bold", "EditorFonts")
	var bold_size: int = get_theme_font_size("bold_size", "EditorFonts")
	var normal_color: Color = get_theme_color("contrast_color_1", "Editor")
	
	var title_lbl: Label = find_child("HeaderTitle", true, false) as Label
	if title_lbl:
		title_lbl.add_theme_font_override("font", bold_font)
		title_lbl.add_theme_font_size_override("font_size", bold_size)
		title_lbl.add_theme_color_override("font_color", normal_color)
		
	if placeholder_lbl:
		placeholder_lbl.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
		
	if mode_btn:
		mode_btn.icon = get_theme_icon("Console", "EditorIcons")
