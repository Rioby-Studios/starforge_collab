@tool
extends ScrollContainer

## Git UI Tab for StarForge Collab.
## Renders active branches, modified files list with individual CheckBoxes,
## status-themed texts, commit fields, and VCS buttons.

var event_bus: StarForgeEventBus = null
var git_manager: StarForgeGitManager = null
var ui_controller: StarForgeGitUiController = null

# UI Control references
var branch_label: Label
var status_label: Label
var files_vbox: VBoxContainer
var placeholder_lbl: Label
var commit_message_input: LineEdit
var feedback_label: Label

var refresh_btn: Button
var stage_all_btn: Button
var commit_btn: Button
var pull_btn: Button
var push_btn: Button

## Binds the EventBus and GitManager dependencies passed from the dock panel.
func setup(p_event_bus: StarForgeEventBus, p_git_manager: StarForgeGitManager) -> void:
	event_bus = p_event_bus
	git_manager = p_git_manager
	ui_controller = StarForgeGitUiController.new(git_manager, event_bus)

func _ready() -> void:
	# Enforce scroll boundaries to guarantee layout safety inside editor docks
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var margin_container: MarginContainer = MarginContainer.new()
	margin_container.add_theme_constant_override("margin_left", 12)
	margin_container.add_theme_constant_override("margin_top", 12)
	margin_container.add_theme_constant_override("margin_right", 12)
	margin_container.add_theme_constant_override("margin_bottom", 12)
	margin_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(margin_container)
	
	var main_vbox: VBoxContainer = VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", 12)
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin_container.add_child(main_vbox)
	
	# --- Header Layout ---
	var header_hbox: HBoxContainer = HBoxContainer.new()
	header_hbox.add_theme_constant_override("separation", 8)
	header_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(header_hbox)
	
	var branch_icon: TextureRect = TextureRect.new()
	branch_icon.name = "BranchIcon"
	branch_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	branch_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header_hbox.add_child(branch_icon)
	
	branch_label = Label.new()
	branch_label.text = "Branch: Carregando..."
	branch_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header_hbox.add_child(branch_label)
	
	var spacer: Control = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_hbox.add_child(spacer)
	
	status_label = Label.new()
	status_label.text = "Repositório Limpo"
	status_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header_hbox.add_child(status_label)
	
	var sep: HSeparator = HSeparator.new()
	main_vbox.add_child(sep)
	
	# --- Central Modified Files Area ---
	var files_scroll: ScrollContainer = ScrollContainer.new()
	files_scroll.custom_minimum_size = Vector2(0, 160)
	files_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	files_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	files_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	files_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	main_vbox.add_child(files_scroll)
	
	files_vbox = VBoxContainer.new()
	files_vbox.add_theme_constant_override("separation", 6)
	files_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	files_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	files_scroll.add_child(files_vbox)
	
	placeholder_lbl = Label.new()
	placeholder_lbl.text = "Sem alterações pendentes."
	placeholder_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	placeholder_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	placeholder_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	files_vbox.add_child(placeholder_lbl)
	
	var footer_sep: HSeparator = HSeparator.new()
	main_vbox.add_child(footer_sep)
	
	# --- Footer Commit Fields & Buttons ---
	var footer_vbox: VBoxContainer = VBoxContainer.new()
	footer_vbox.add_theme_constant_override("separation", 8)
	footer_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(footer_vbox)
	
	commit_message_input = LineEdit.new()
	commit_message_input.placeholder_text = "Mensagem do commit..."
	commit_message_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer_vbox.add_child(commit_message_input)
	
	var actions_grid: GridContainer = GridContainer.new()
	actions_grid.columns = 3
	actions_grid.add_theme_constant_override("h_separation", 6)
	actions_grid.add_theme_constant_override("v_separation", 6)
	actions_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer_vbox.add_child(actions_grid)
	
	refresh_btn = Button.new()
	refresh_btn.text = "Refresh"
	refresh_btn.focus_mode = Control.FOCUS_NONE
	refresh_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_grid.add_child(refresh_btn)
	refresh_btn.pressed.connect(refresh_git_status)
	
	stage_all_btn = Button.new()
	stage_all_btn.text = "Stage All"
	stage_all_btn.focus_mode = Control.FOCUS_NONE
	stage_all_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_grid.add_child(stage_all_btn)
	stage_all_btn.pressed.connect(_on_stage_all_pressed)
	
	commit_btn = Button.new()
	commit_btn.text = "Commit"
	commit_btn.focus_mode = Control.FOCUS_NONE
	commit_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_grid.add_child(commit_btn)
	commit_btn.pressed.connect(_on_commit_pressed)
	
	pull_btn = Button.new()
	pull_btn.text = "Pull"
	pull_btn.focus_mode = Control.FOCUS_NONE
	pull_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_grid.add_child(pull_btn)
	pull_btn.pressed.connect(_on_pull_pressed)
	
	push_btn = Button.new()
	push_btn.text = "Push"
	push_btn.focus_mode = Control.FOCUS_NONE
	push_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_grid.add_child(push_btn)
	push_btn.pressed.connect(_on_push_pressed)
	
	feedback_label = Label.new()
	feedback_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	footer_vbox.add_child(feedback_label)
	
	# Initial fetch
	refresh_git_status()
	
	# Connect to EventBus signal if needed
	if event_bus != null:
		event_bus.connect_event("git_status_changed", func(status):
			_on_git_status_changed_received()
		)
	
	theme_changed.connect(_apply_theme)
	_apply_theme()

## Scans the workspace directory and lists modified resources.
func refresh_git_status() -> void:
	if ui_controller == null:
		return
		
	var info: Dictionary = ui_controller.refresh_status()
	
	if not info["is_repository"]:
		branch_label.text = "Erro: Repositório Git não detectado."
		status_label.text = "Não Inicializado"
		status_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))
		_clear_files_list()
		placeholder_lbl.text = "Por favor, inicialize um repositório Git na raiz do seu projeto Godot."
		placeholder_lbl.visible = true
		_set_buttons_disabled(true)
		return
		
	_set_buttons_disabled(false)
	
	# Update branch header
	branch_label.text = "Branch: " + info["branch"]
	
	# Populate file lists
	var status_dict: Dictionary = info["status"]
	var staged: Array = status_dict.get("staged", [])
	var unstaged: Array = status_dict.get("unstaged", [])
	var untracked: Array = status_dict.get("untracked", [])
	
	_clear_files_list()
	
	var total_changes: int = staged.size() + unstaged.size() + untracked.size()
	if total_changes == 0:
		status_label.text = "Repositório Limpo"
		status_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
		placeholder_lbl.text = "Sem alterações pendentes."
		placeholder_lbl.visible = true
	else:
		status_label.text = "%d Pendência(s)" % total_changes
		status_label.add_theme_color_override("font_color", get_theme_color("warning_color", "Editor"))
		placeholder_lbl.visible = false
		
		# Build staged items (Blue)
		for file_path in staged:
			_create_file_item(file_path, "staged", true)
			
		# Build unstaged modifications (Yellow)
		for file_path in unstaged:
			# Avoid listing staged duplicates in simple list
			if not staged.has(file_path):
				_create_file_item(file_path, "unstaged", false)
				
		# Build untracked new files (Green)
		for file_path in untracked:
			_create_file_item(file_path, "untracked", false)

func _clear_files_list() -> void:
	for child in files_vbox.get_children():
		if child != placeholder_lbl:
			child.queue_free()

func _set_buttons_disabled(disabled: bool) -> void:
	stage_all_btn.disabled = disabled
	commit_btn.disabled = disabled
	pull_btn.disabled = disabled
	push_btn.disabled = disabled

func _create_file_item(file_path: String, type: String, is_staged: bool) -> void:
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	files_vbox.add_child(row)
	
	var checkbox: CheckBox = CheckBox.new()
	checkbox.button_pressed = is_staged
	checkbox.focus_mode = Control.FOCUS_NONE
	row.add_child(checkbox)
	
	var file_lbl: Label = Label.new()
	file_lbl.text = file_path
	file_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	file_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(file_lbl)
	
	# Apply themed status colors
	var color: Color
	match type:
		"staged":
			color = get_theme_color("accent_color", "Editor") # Blue accent
		"unstaged":
			color = get_theme_color("warning_color", "Editor") # Orange modification
		"untracked":
			color = get_theme_color("success_color", "Editor") # Green new files
			
	file_lbl.add_theme_color_override("font_color", color)
	
	# Connect checkbox toggles directly to git manager stage / unstage
	checkbox.toggled.connect(func(pressed):
		if git_manager == null:
			return
		if pressed:
			git_manager.git_add_file(file_path)
		else:
			git_manager.git_reset_file(file_path)
		# Defer a fast refresh to consolidate list states
		get_tree().create_timer(0.1).timeout.connect(refresh_git_status)
	)

func _on_stage_all_pressed() -> void:
	if ui_controller == null:
		return
	if ui_controller.stage_all():
		feedback_label.text = "Todas as alterações adicionadas (staged)!"
		feedback_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
		refresh_git_status()
	else:
		feedback_label.text = "Falha ao adicionar alterações."
		feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))

func _on_commit_pressed() -> void:
	if ui_controller == null:
		return
	var msg: String = commit_message_input.text.strip_edges()
	if msg.is_empty():
		feedback_label.text = "Erro: Escreva uma mensagem de commit!"
		feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))
		return
		
	var result: StarForgeGitOperationResult = ui_controller.commit(msg)
	if result.success:
		feedback_label.text = "Commit realizado com sucesso!"
		feedback_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
		commit_message_input.text = ""
		refresh_git_status()
	else:
		feedback_label.text = "Erro no commit: " + result.error_message
		feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))

func _on_pull_pressed() -> void:
	if ui_controller == null:
		return
	feedback_label.text = "Sincronizando com o servidor remoto (Pull)..."
	feedback_label.add_theme_color_override("font_color", get_theme_color("contrast_color_2", "Editor"))
	
	# Wait briefly to let label draw
	await get_tree().process_frame
	var result: StarForgeGitOperationResult = ui_controller.pull()
	if result.success:
		feedback_label.text = "Sincronizado (Pull) com sucesso!"
		feedback_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
		refresh_git_status()
	else:
		feedback_label.text = "Erro no Pull: " + result.error_message
		feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))

func _on_push_pressed() -> void:
	if ui_controller == null:
		return
	feedback_label.text = "Enviando alterações para o remoto (Push)..."
	feedback_label.add_theme_color_override("font_color", get_theme_color("contrast_color_2", "Editor"))
	
	# Wait briefly
	await get_tree().process_frame
	var result: StarForgeGitOperationResult = ui_controller.push()
	if result.success:
		feedback_label.text = "Enviado (Push) com sucesso!"
		feedback_label.add_theme_color_override("font_color", get_theme_color("success_color", "Editor"))
		refresh_git_status()
	else:
		feedback_label.text = "Erro no Push: " + result.error_message
		feedback_label.add_theme_color_override("font_color", get_theme_color("error_color", "Editor"))

func _on_git_status_changed_received() -> void:
	# Trigger refresh if someone else signals changes
	refresh_git_status()

func _apply_theme() -> void:
	if not is_inside_tree():
		return
		
	var branch_icon_node: TextureRect = find_child("BranchIcon", true, false) as TextureRect
	if branch_icon_node:
		branch_icon_node.texture = get_theme_icon("VcsBranches", "EditorIcons")
		branch_icon_node.self_modulate = get_theme_color("contrast_color_1", "Editor")
		
	# Format branch label to be bold
	if branch_label:
		branch_label.add_theme_font_override("font", get_theme_font("bold", "EditorFonts"))
		
	if status_label:
		status_label.add_theme_font_override("font", get_theme_font("bold", "EditorFonts"))
		
	# Placeholder text sutil
	if placeholder_lbl:
		placeholder_lbl.add_theme_color_override("font_color", get_theme_color("disabled_font_color", "Editor"))
