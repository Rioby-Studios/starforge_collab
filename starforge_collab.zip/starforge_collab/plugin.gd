@tool
extends EditorPlugin

## Entry point for the StarForge Collab Godot 4 plugin.
## Orchestrates all core frameworks, registers modules, setups the Discord bridge,
## runs the FileWatcher, and ensures zero leaks and safe PID terminations upon deactivation.

var event_bus: StarForgeEventBus = null
var settings_manager: StarForgeSettingsManager = null
var module_manager: StarForgeModuleManager = null
var dock_instance: StarForgeDockMain = null

var git_manager: StarForgeGitManager = null
var file_watcher: StarForgeFileWatcher = null
var activity_manager: StarForgeActivityManager = null
var bot_manager: StarForgeDiscordBotManager = null
var discord_bridge: StarForgeDiscordBridge = null

# Concrete module instances
var activity_module: StarForgeModule = null
var git_module: StarForgeModule = null
var team_module: StarForgeModule = null
var chat_module: StarForgeModule = null
var settings_module: StarForgeModule = null

func _enter_tree() -> void:
	# 1. Instantiate Central Event Bus
	event_bus = StarForgeEventBus.new()
	
	# 2. Initialize Settings Manager and Register Project Configurations
	settings_manager = StarForgeSettingsManager.new(event_bus)
	settings_manager.register_settings()
	
	# 3. Initialize Module Manager with EventBus and Settings references
	module_manager = StarForgeModuleManager.new(event_bus, settings_manager)
	
	# 4. Instantiate and Register concrete StarForge modules
	_register_core_modules()
	
	# 5. Initialize Git Manager, Activity Manager, and Bot Manager
	git_manager = StarForgeGitManager.new(settings_manager)
	activity_manager = StarForgeActivityManager.new(event_bus)
	bot_manager = StarForgeDiscordBotManager.new(settings_manager)
	
	# 6. Initialize FileWatcher and start monitoring resources
	file_watcher = StarForgeFileWatcher.new(event_bus)
	file_watcher.start()
	
	# 7. Initialize Discord Bridge Node and mount it as a child
	discord_bridge = StarForgeDiscordBridge.new()
	discord_bridge.name = "StarForgeDiscordBridge"
	add_child(discord_bridge)
	discord_bridge.setup(event_bus, bot_manager)
	
	# If settings enable the bridge, start it automatically
	var auto_bridge: bool = settings_manager.get_setting(StarForgeSettingsManager.SETTING_ENABLE_DISCORD_BRIDGE, false) as bool
	if auto_bridge:
		if bot_manager.is_bot_running():
			discord_bridge.start_bridge()
	
	# 8. Instantiate Main UI Dock Panel
	dock_instance = StarForgeDockMain.new(
		event_bus, 
		settings_manager,
		git_manager,
		file_watcher,
		activity_manager,
		bot_manager,
		discord_bridge
	)
	
	# 9. Add Dock Panel to bottom-right Editor dock slot
	add_control_to_dock(DOCK_SLOT_RIGHT_BL, dock_instance)
	
	# Log final success confirmation
	StarForgeLogger.info("StarForge Collab core framework & modules initialized successfully.", "Core")

func _exit_tree() -> void:
	# 1. Stop and remove the Discord Bridge node dynamically (handles PID deactivation)
	if discord_bridge:
		discord_bridge.stop_bridge()
		remove_child(discord_bridge)
		discord_bridge.queue_free()
		discord_bridge = null
		
	# 2. Stop and free the FileWatcher
	if file_watcher:
		file_watcher.stop()
		file_watcher = null
		
	# 3. Safely remove and free the Dock Panel UI
	if dock_instance:
		remove_control_from_docks(dock_instance)
		dock_instance.queue_free()
		dock_instance = null
		
	# 4. Deactivate and clear all modules in ModuleManager
	if module_manager:
		module_manager.cleanup()
		module_manager = null
		
	# Free local references to concrete modules to avoid memory leaks
	activity_module = null
	git_module = null
	team_module = null
	chat_module = null
	settings_module = null
		
	# 5. Clean up managers
	git_manager = null
	activity_manager = null
	bot_manager = null
		
	# 6. Unregister and purge project settings keys
	if settings_manager:
		settings_manager.unregister_settings()
		settings_manager = null
		
	# 7. Clear Event Bus reference
	if event_bus:
		event_bus = null
		
	# Log successful shutdown
	StarForgeLogger.info("StarForge Collab deactivated and cleaned up.", "Core")

func _register_core_modules() -> void:
	# Load concrete module scripts dynamically
	var activity_script: GDScript = load("res://addons/starforge_collab/core/module_activity.gd") as GDScript
	var git_script: GDScript = load("res://addons/starforge_collab/core/module_git.gd") as GDScript
	var team_script: GDScript = load("res://addons/starforge_collab/core/module_team.gd") as GDScript
	var chat_script: GDScript = load("res://addons/starforge_collab/core/module_chat.gd") as GDScript
	var settings_script: GDScript = load("res://addons/starforge_collab/core/module_settings.gd") as GDScript
	
	if activity_script:
		activity_module = activity_script.new() as StarForgeModule
		module_manager.register_module(activity_module)
		
	if git_script:
		git_module = git_script.new() as StarForgeModule
		module_manager.register_module(git_module)
		
	if team_script:
		team_module = team_script.new() as StarForgeModule
		module_manager.register_module(team_module)
		
	if chat_script:
		chat_module = chat_script.new() as StarForgeModule
		module_manager.register_module(chat_module)
		
	if settings_script:
		settings_module = settings_script.new() as StarForgeModule
		module_manager.register_module(settings_module)
