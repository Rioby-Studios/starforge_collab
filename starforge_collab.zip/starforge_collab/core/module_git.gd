@tool
extends StarForgeModule

func _init() -> void:
	super._init("git", "Git Integration", "0.1.0")
