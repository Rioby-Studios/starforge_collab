@tool
extends StarForgeModule

func _init() -> void:
	super._init("activity", "Activity Feed", "0.1.0")
