@tool
class_name StarForgeModuleManager
extends RefCounted

## Manages the registration, initialization, and deactivation lifecycle of StarForge modules.
## Ensures modules receive EventBus, Logger, and SettingsManager dependencies securely.

var event_bus: StarForgeEventBus = null
var settings_manager: StarForgeSettingsManager = null
var modules: Dictionary = {} # String (module_id) -> StarForgeModule

func _init(p_event_bus: StarForgeEventBus, p_settings_manager: StarForgeSettingsManager) -> void:
	event_bus = p_event_bus
	settings_manager = p_settings_manager

## Registers, initializes, and triggers the ready event for a module.
func register_module(module: StarForgeModule) -> bool:
	if module == null:
		StarForgeLogger.error("Cannot register null module.", "ModuleManager")
		return false
	
	if modules.has(module.module_id):
		StarForgeLogger.warn("Module '%s' is already registered." % module.module_id, "ModuleManager")
		return false
	
	modules[module.module_id] = module
	
	# Pass EventBus, Logger class, and SettingsManager
	module._module_init(event_bus, StarForgeLogger, settings_manager)
	module._module_ready()
	
	if event_bus != null:
		event_bus.module_registered.emit(module.module_id)
		
	StarForgeLogger.info("Module '%s' (%s) registered successfully." % [module.module_name, module.module_id], "ModuleManager")
	return true

## Unregisters and triggers cleanup for a module.
func unregister_module(module_id: String) -> bool:
	if not modules.has(module_id):
		StarForgeLogger.warn("Cannot unregister. Module '%s' is not registered." % module_id, "ModuleManager")
		return false
	
	var module: StarForgeModule = modules[module_id]
	module._module_cleanup()
	modules.erase(module_id)
	
	if event_bus != null:
		event_bus.module_unregistered.emit(module_id)
		
	StarForgeLogger.info("Module '%s' unregistered successfully." % module_id, "ModuleManager")
	return true

## Retrieves a registered module by its ID.
func get_module(module_id: String) -> StarForgeModule:
	return modules.get(module_id, null) as StarForgeModule

## Returns an array of all currently registered modules.
func get_all_modules() -> Array:
	return modules.values()

## Safely cleans up all registered modules in reverse order.
func cleanup() -> void:
	StarForgeLogger.info("Cleaning up all modules...", "ModuleManager")
	var keys: Array = modules.keys()
	keys.reverse()
	for key in keys:
		unregister_module(key)
	modules.clear()
