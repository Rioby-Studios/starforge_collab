@tool
extends StarForgeModule

func _init() -> void:
	super._init("team", "Team Workspace", "0.1.0")
