@tool
class_name StarForgeLogger
extends RefCounted

## Professional Logger for the StarForge Collab plugin.
## Manages log levels, message formatting, and console integration.

static var current_level: int = StarForgeConstants.LogLevel.INFO

## Configures the minimum logging level.
static func set_level(level: int) -> void:
	current_level = level

## Logs a debug-level message.
static func debug(message: String, module_name: String = "") -> void:
	if current_level <= StarForgeConstants.LogLevel.DEBUG:
		_print_log("DEBUG", message, module_name)

## Logs an info-level message.
static func info(message: String, module_name: String = "") -> void:
	if current_level <= StarForgeConstants.LogLevel.INFO:
		_print_log("INFO", message, module_name)

## Logs a warning-level message.
static func warn(message: String, module_name: String = "") -> void:
	if current_level <= StarForgeConstants.LogLevel.WARN:
		var formatted: String = _format_msg("WARN", message, module_name)
		push_warning(formatted)
		print(formatted)

## Logs an error-level message.
static func error(message: String, module_name: String = "") -> void:
	if current_level <= StarForgeConstants.LogLevel.ERROR:
		var formatted: String = _format_msg("ERROR", message, module_name)
		push_error(formatted)
		print(formatted)

static func _format_msg(level_str: String, message: String, module_name: String) -> String:
	var mod_part: String = "" if module_name.is_empty() else "[%s]" % module_name
	return "%s[%s]%s %s" % [StarForgeConstants.LOG_PREFIX, level_str, mod_part, message]

static func _print_log(level_str: String, message: String, module_name: String) -> void:
	print(_format_msg(level_str, message, module_name))
