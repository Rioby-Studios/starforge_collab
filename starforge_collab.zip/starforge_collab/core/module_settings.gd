@tool
extends StarForgeModule

func _init() -> void:
	super._init("settings", "Settings", "0.1.0")
