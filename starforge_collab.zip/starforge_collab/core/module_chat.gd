@tool
extends StarForgeModule

func _init() -> void:
	super._init("chat", "Team Chat", "0.1.0")
