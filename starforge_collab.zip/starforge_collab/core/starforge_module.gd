@tool
class_name StarForgeModule
extends RefCounted

## Base class for all StarForge Collab modules.
## Defines the lifecycle signature and stores necessary core references.

var module_id: String = ""
var module_name: String = ""
var module_version: String = "0.1.0"

var event_bus: StarForgeEventBus = null
var settings_manager: StarForgeSettingsManager = null
var is_active: bool = false

func _init(id: String, name: String, version: String = "0.1.0") -> void:
	module_id = id
	module_name = name
	module_version = version

## Sets up the module dependencies and flags it as active.
func _module_init(p_event_bus: StarForgeEventBus, p_logger: Variant, p_settings_manager: StarForgeSettingsManager) -> void:
	event_bus = p_event_bus
	settings_manager = p_settings_manager
	is_active = true
	StarForgeLogger.debug("Module initialized.", module_name)

## Invoked once all modules have completed setup.
func _module_ready() -> void:
	StarForgeLogger.debug("Module ready.", module_name)

## Safely tears down the module and clears dependencies.
func _module_cleanup() -> void:
	is_active = false
	event_bus = null
	settings_manager = null
	StarForgeLogger.debug("Module cleaned up.", module_name)
