@tool
class_name StarForgeEventBus
extends Object

## Central Event Bus for the StarForge Collab plugin.
## Enables fully decoupled communication between modules using typed signals
## and a generic reflective API (`emit_event` and `connect_event`).

# --- Core Lifecycle Signals ---
signal module_registered(module_id: String)
signal module_unregistered(module_id: String)

# --- UI Signals ---
signal tab_changed(tab_name: String)

# --- Settings Signals ---
signal setting_changed(setting_name: String, value: Variant)

# --- Activity Feed Signals ---
signal activity_created(activity_data: Dictionary)

# --- Git Version Control Signals ---
signal git_status_changed(status: Dictionary)
signal git_operation_completed(operation: String)

# --- Team & Presence Signals ---
signal member_joined(member_name: String)
signal member_left(member_name: String)

# --- Chat Signals ---
signal message_received(message_data: Dictionary)


## Emits a signal by name, dynamically unpacking the given data array.
func emit_event(event_name: String, data: Array = []) -> void:
	if has_signal(event_name):
		var args: Array = [event_name]
		args.append_array(data)
		# Dynamically call emit_signal with unpacked arguments array
		self.callv("emit_signal", args)
	else:
		StarForgeLogger.warn("Attempted to emit unregistered event: %s" % event_name, "EventBus")

## Connects a Callable to a signal by name.
func connect_event(event_name: String, callable: Callable) -> Error:
	if has_signal(event_name):
		# Avoid duplicate connections
		if is_connected(event_name, callable):
			return OK
		return connect(event_name, callable)
	
	StarForgeLogger.error("Cannot connect event. Unregistered event name: %s" % event_name, "EventBus")
	return ERR_INVALID_PARAMETER
