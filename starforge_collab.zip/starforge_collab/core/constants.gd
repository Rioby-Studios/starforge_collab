@tool
class_name StarForgeConstants
extends RefCounted

## Constants for the StarForge Collab plugin.
## Defines global values, version details, and configuration settings paths.

const PLUGIN_NAME: String = "StarForge Collab"
const PLUGIN_VERSION: String = "0.1.0"
const PLUGIN_PREFIX: String = "starforge_collab"
const LOG_PREFIX: String = "[StarForge]"

enum LogLevel {
	DEBUG = 0,
	INFO = 1,
	WARN = 2,
	ERROR = 3
}

# Standard configuration and cache paths
const SETTINGS_PATH: String = "starforge_collab/general/"
const CACHE_PATH: String = "user://starforge_collab_cache/"

# Settings paths for Godot's ProjectSettings/EditorSettings
const SETTING_LOG_LEVEL: String = "starforge_collab/general/log_level"
const SETTING_ACTIVE_TAB: String = "starforge_collab/general/active_tab"
const SETTING_AUTO_REFRESH: String = "starforge_collab/general/auto_refresh"
const SETTING_NOTIFICATIONS_ENABLED: String = "starforge_collab/general/notifications_enabled"
const SETTING_DISCORD_RPC: String = "starforge_collab/general/enable_discord_rpc"
const SETTING_GIT_AUTO_COMMIT: String = "starforge_collab/general/git_auto_commit"
