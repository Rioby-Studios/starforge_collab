@tool
class_name StarForgeDiscordBotManager
extends RefCounted

## Manages the execution cycle of the local Python bot using OS.create_process().
## Handles background spawns, log redirections, and diagnostics.

var bot_pid: int = 0
var settings_manager: StarForgeSettingsManager = null

func _init(p_settings: StarForgeSettingsManager) -> void:
	settings_manager = p_settings

## Spawns the local Python bot in the background, passing credentials via memory args.
func start_bot(token: String, channel_id: int, logs_channel_id: int = 0) -> bool:
	if is_bot_running():
		StarForgeLogger.warn("Bot is already running.", "BotManager")
		return true
		
	var log_path: String = ProjectSettings.globalize_path("user://starforge_bot.log")
	
	# Delete previous log file to prevent stale logs during connection diagnostics
	if FileAccess.file_exists(log_path):
		DirAccess.remove_absolute(log_path)
		
	# Verify Python environment before starting
	var py_check_err: String = verify_python_env()
	if not py_check_err.is_empty():
		var file: FileAccess = FileAccess.open(log_path, FileAccess.WRITE)
		if file:
			file.store_string("Erro de Ambiente:\n" + py_check_err)
			file.close()
		StarForgeLogger.error(py_check_err, "BotManager")
		return false
		
	var script_path: String = ProjectSettings.globalize_path("res://addons/starforge_collab/discord/local_bot/starforge_discord_bot.py")
	var python_path: String = _get_python_executable()
	
	var args: PackedStringArray = PackedStringArray([
		script_path,
		"--token", token,
		"--channel_id", str(channel_id),
		"--log_file", log_path
	])
	
	if logs_channel_id > 0:
		args.append("--logs_channel_id")
		args.append(str(logs_channel_id))
		
	# Spawn process in background, returning PID
	bot_pid = OS.create_process(python_path, args)
	
	if bot_pid > 0:
		StarForgeLogger.info("Local Python bot process spawned with PID: %d. Logs redirected to %s." % [bot_pid, log_path], "BotManager")
		return true
	else:
		# Fallback attempt using "python3" on Unix systems if "python" fails
		bot_pid = OS.create_process("python3", args)
		if bot_pid > 0:
			StarForgeLogger.info("Local Python bot process spawned with PID: %d (via python3)." % bot_pid, "BotManager")
			return true
			
		StarForgeLogger.error("Failed to spawn Python process. Make sure python or python3 is in your system PATH.", "BotManager")
		return false

## Validates Python availability and required dependencies
func verify_python_env() -> String:
	var py_path: String = _get_python_executable()
	
	var output: Array = []
	var exit_code: int = OS.execute(py_path, ["-c", "import discord, aiohttp"], output, true)
	if exit_code == 0:
		return ""
		
	# Check if python executable exists at all
	output.clear()
	var test_exit: int = OS.execute(py_path, ["--version"], output, true)
	if test_exit != 0:
		return "Python não está instalado ou não foi encontrado no PATH do sistema."
			
	return "Python encontrado, mas as bibliotecas requisitadas (discord.py, aiohttp) não estão instaladas.\nPor favor, execute: pip install discord.py aiohttp"

## Finds the absolute path to python.exe or returns "python" if not found (relying on PATH)
func _get_python_executable() -> String:
	# 1. Check if "python" in PATH works
	var output: Array = []
	if OS.execute("python", ["-c", "import sys"], output, true) == 0:
		return "python"
		
	# 2. Check standard Windows custom install paths (helps avoid requiring a Godot restart after install)
	var local_appdata: String = OS.get_environment("LOCALAPPDATA")
	if not local_appdata.is_empty():
		var bin_path: String = local_appdata.path_join("Python/bin/python.exe")
		if FileAccess.file_exists(bin_path):
			return bin_path
			
		var core_path: String = local_appdata.path_join("Python/pythoncore-3.14-64/python.exe")
		if FileAccess.file_exists(core_path):
			return core_path
			
		var programs_dir: String = local_appdata.path_join("Programs/Python")
		if DirAccess.dir_exists_absolute(programs_dir):
			var dir: DirAccess = DirAccess.open(programs_dir)
			if dir:
				dir.list_dir_begin()
				var folder_name: String = dir.get_next()
				while not folder_name.is_empty():
					if folder_name.begins_with("Python"):
						var check_path: String = programs_dir.path_join(folder_name).path_join("python.exe")
						if FileAccess.file_exists(check_path):
							return check_path
					folder_name = dir.get_next()
					
	# 3. Check Unix python3 fallback
	if OS.execute("python3", ["-c", "import sys"], output, true) == 0:
		return "python3"
		
	return "python"

## Returns true if the Python bot process is active in the operating system.
func is_bot_running() -> bool:
	if bot_pid <= 0:
		return false
	return OS.is_process_running(bot_pid)

## Forcefully terminates the Python bot background process.
func stop_bot() -> void:
	if bot_pid <= 0:
		return
		
	if OS.is_process_running(bot_pid):
		OS.kill(bot_pid)
		StarForgeLogger.info("Local Python bot process terminated (PID %d)." % bot_pid, "BotManager")
		
	bot_pid = 0

## Reads the bot log file to extract Python tracebacks or connection errors.
func get_last_bot_error() -> String:
	var log_path: String = "user://starforge_bot.log"
	if not FileAccess.file_exists(log_path):
		return ""
		
	var file: FileAccess = FileAccess.open(log_path, FileAccess.READ)
	if not file:
		return ""
		
	var content: String = file.get_as_text()
	file.close()
	
	if content.is_empty():
		return ""
		
	var lines: PackedStringArray = content.split("\n", false)
	
	# Strip lines for cleaner parsing
	var cleaned_lines: Array = []
	for line in lines:
		cleaned_lines.append(line.strip_edges())
		
	var error_trace: Array = []
	var found_error: bool = false
	
	# Scan backwards to capture tracebacks or error exceptions
	for i in range(cleaned_lines.size() - 1, -1, -1):
		var line: String = cleaned_lines[i] as String
		if line.is_empty():
			continue
			
		if "ModuleNotFoundError" in line or "LoginFailure" in line or "Exception" in line or "Error" in line or "Traceback" in line:
			found_error = true
			
		if found_error:
			error_trace.insert(0, line)
			if error_trace.size() >= 5: # Capture up to 5 lines of traceback
				break
				
	if error_trace.size() > 0:
		return "\n".join(error_trace)
		
	# Fallback: return the last 2 lines
	var fallback_lines: Array = []
	for i in range(cleaned_lines.size() - 1, -1, -1):
		var line: String = cleaned_lines[i] as String
		if not line.is_empty():
			fallback_lines.insert(0, line)
			if fallback_lines.size() >= 2:
				break
	return "\n".join(fallback_lines)
