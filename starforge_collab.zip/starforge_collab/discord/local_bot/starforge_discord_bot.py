import asyncio
import argparse
import sys
import traceback
from aiohttp import web
import discord

## StarForge Discord Bot Local Bridge
## Spawns a background discord.py worker and exposes a local REST API on port 5981.
## Credentials are passed only in memory via command line arguments for security.

parser = argparse.ArgumentParser(description="StarForge Discord Bot Local Bridge")
parser.add_argument("--token", required=True, help="Discord Bot Token")
parser.add_argument("--channel_id", type=int, required=True, help="Primary Discord Chat Channel ID")
parser.add_argument("--logs_channel_id", type=int, help="Optional Discord Log Channel ID")
parser.add_argument("--log_file", help="Optional absolute path to redirect bot console outputs")
args = parser.parse_args()

# Redirect stdout/stderr if a log file was requested
if args.log_file:
	try:
		log_writer = open(args.log_file, "w", encoding="utf-8", buffering=1)
		sys.stdout = log_writer
		sys.stderr = log_writer
	except Exception as e:
		print(f"Failed to redirect logs: {e}", file=sys.stderr)

# Discord intents setup
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
client = discord.Client(intents=intents)

# Thread-safe queue of incoming Discord messages
incoming_messages = []
ready_event = asyncio.Event()

@client.event
async def on_ready():
	print(f"[StarForgeBot] Bot logged in as {client.user}", flush=True)
	ready_event.set()

@client.event
async def on_message(message):
	# Ignore messages sent by other bots or self
	if message.author.bot:
		return
		
	# Route incoming message to primary chat queue
	if message.channel.id == args.channel_id:
		msg_data = {
			"author": message.author.display_name,
			"content": message.content,
			"timestamp": int(message.created_at.timestamp())
		}
		incoming_messages.append(msg_data)
		print(f"[StarForgeBot] Message queued: [{msg_data['author']}]: {msg_data['content']}", flush=True)

# --- HTTP Endpoints ---

async def get_status(request):
	status_str = "connected" if client.is_ready() else "connecting"
	return web.json_response({
		"status": status_str,
		"bot_user": str(client.user) if client.user else None,
		"primary_channel": args.channel_id
	})

async def send_message(request):
	if not client.is_ready():
		return web.json_response({"success": False, "error": "Bot not fully connected"}, status=503)
		
	try:
		data = await request.json()
		text = data.get("text", "")
		if not text:
			return web.json_response({"success": False, "error": "Missing message text"}, status=400)
			
		channel = client.get_channel(args.channel_id)
		if not channel:
			channel = await client.fetch_channel(args.channel_id)
			
		if channel:
			await channel.send(text)
			return web.json_response({"success": True})
		else:
			return web.json_response({"success": False, "error": "Channel not found"}, status=404)
	except Exception as e:
		return web.json_response({"success": False, "error": str(e)}, status=500)

async def get_messages(request):
	global incoming_messages
	# Pop messages from queue and clear cache
	queue = list(incoming_messages)
	incoming_messages.clear()
	return web.json_response({"messages": queue})

async def shutdown_bot(request):
	print("[StarForgeBot] Shutdown requested...", flush=True)
	asyncio.create_task(cleanup())
	return web.json_response({"success": True})

async def cleanup():
	await asyncio.sleep(0.5)
	await client.close()
	sys.exit(0)

# --- Server Start ---

async def main():
	app = web.Application()
	app.router.add_get("/status", get_status)
	app.router.add_post("/send", send_message)
	app.router.add_get("/messages", get_messages)
	app.router.add_post("/shutdown", shutdown_bot)
	
	runner = web.AppRunner(app)
	await runner.setup()
	site = web.TCPSite(runner, "127.0.0.1", 5981)
	
	await site.start()
	print("[StarForgeBot] Local HTTP bridge listening on http://127.0.0.1:5981", flush=True)
	
	try:
		await client.start(args.token)
	except Exception as e:
		print(f"[StarForgeBot] Discord connection error: {e}", file=sys.stderr, flush=True)
		await site.stop()
		sys.exit(1)

if __name__ == "__main__":
	try:
		asyncio.run(main())
	except KeyboardInterrupt:
		print("[StarForgeBot] Exiting...", flush=True)
	except Exception as e:
		traceback.print_exc(file=sys.stderr)
		sys.exit(1)
