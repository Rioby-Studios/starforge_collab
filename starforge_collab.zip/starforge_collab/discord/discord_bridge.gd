@tool
class_name StarForgeDiscordBridge
extends Node

## Facilitates HTTP communication between Godot and the Local Python Bot.
## Runs a periodic polling timer to fetch status and sync incoming Discord chats.

var event_bus: StarForgeEventBus = null
var bot_manager: StarForgeDiscordBotManager = null

var poll_timer: Timer = null
var status_http: HTTPRequest = null
var messages_http: HTTPRequest = null
var send_http: HTTPRequest = null
var shutdown_http: HTTPRequest = null

var is_connected_to_bot: bool = false

## Binds the necessary core systems during startup.
func setup(p_event_bus: StarForgeEventBus, p_bot_manager: StarForgeDiscordBotManager) -> void:
	event_bus = p_event_bus
	bot_manager = p_bot_manager

func _ready() -> void:
	# 1. Allocate HTTPRequest nodes programmatically
	status_http = HTTPRequest.new()
	status_http.name = "StatusHTTP"
	add_child(status_http)
	status_http.request_completed.connect(_on_status_request_completed)
	
	messages_http = HTTPRequest.new()
	messages_http.name = "MessagesHTTP"
	add_child(messages_http)
	messages_http.request_completed.connect(_on_messages_request_completed)
	
	send_http = HTTPRequest.new()
	send_http.name = "SendHTTP"
	add_child(send_http)
	
	shutdown_http = HTTPRequest.new()
	shutdown_http.name = "ShutdownHTTP"
	add_child(shutdown_http)
	
	# 2. Setup periodic polling loop
	poll_timer = Timer.new()
	poll_timer.name = "PollTimer"
	poll_timer.wait_time = 2.5
	poll_timer.one_shot = false
	add_child(poll_timer)
	poll_timer.timeout.connect(_on_poll_timeout)

## Starts the polling timer.
func start_bridge() -> void:
	if poll_timer:
		poll_timer.start()
		_on_poll_timeout() # Trigger immediate query
	StarForgeLogger.info("Discord Bridge active.", "DiscordBridge")

## Shuts down polling and triggers bot deactivation.
func stop_bridge() -> void:
	if poll_timer:
		poll_timer.stop()
	
	# Try sending clean REST shutdown to the bot before killing process
	if bot_manager and bot_manager.is_bot_running():
		shutdown_http.request("http://127.0.0.1:5981/shutdown", PackedStringArray(), HTTPClient.METHOD_POST)
		# Acknowledge shutdown propagation delay
		await get_tree().create_timer(0.4).timeout
		bot_manager.stop_bot()
		
	is_connected_to_bot = false
	StarForgeLogger.info("Discord Bridge stopped.", "DiscordBridge")

## Posts a chat message to the local bot.
func send_chat_message(text: String) -> void:
	if not is_connected_to_bot:
		StarForgeLogger.warn("Cannot send message. Discord Bot is offline.", "DiscordBridge")
		return
		
	var body: String = JSON.stringify({"text": text})
	var headers: PackedStringArray = PackedStringArray(["Content-Type: application/json"])
	send_http.request("http://127.0.0.1:5981/send", headers, HTTPClient.METHOD_POST, body)

func _on_poll_timeout() -> void:
	if bot_manager == null or not bot_manager.is_bot_running():
		is_connected_to_bot = false
		return
		
	# Query status
	status_http.request("http://127.0.0.1:5981/status", PackedStringArray(), HTTPClient.METHOD_GET)
	
	# Fetch queued messages if connected
	if is_connected_to_bot:
		messages_http.request("http://127.0.0.1:5981/messages", PackedStringArray(), HTTPClient.METHOD_GET)

func _on_status_request_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
		var json: JSON = JSON.new()
		if json.parse(body.get_string_from_utf8()) == OK:
			var dict: Dictionary = json.get_data() as Dictionary
			var bot_status: String = dict.get("status", "")
			var was_connected: bool = is_connected_to_bot
			is_connected_to_bot = (bot_status == "connected")
			
			if is_connected_to_bot and not was_connected:
				StarForgeLogger.info("Discord Bot connected and ready.", "DiscordBridge")
				if event_bus != null:
					var bot_name: String = dict.get("bot_user", "StarForgeBot")
					var log_desc: String = StarForgeDiscordActivityFormatter.format_connection(bot_name)
					event_bus.activity_created.emit({
						"timestamp": Time.get_unix_time_from_system() as int,
						"type": "bot_connected",
						"user": "System",
						"description": log_desc
					})
	else:
		is_connected_to_bot = false

func _on_messages_request_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
		var json: JSON = JSON.new()
		if json.parse(body.get_string_from_utf8()) == OK:
			var dict: Dictionary = json.get_data() as Dictionary
			var messages: Array = dict.get("messages", [])
			for msg in messages:
				var parsed: Dictionary = StarForgeDiscordMessageParser.parse_message(msg)
				if event_bus != null:
					# Push message directly to Chat Tab
					event_bus.message_received.emit(parsed)
					
					# Push message to Activity Feed
					var log_desc: String = StarForgeDiscordActivityFormatter.format_received_message(parsed.author, parsed.text)
					event_bus.activity_created.emit({
						"timestamp": parsed.timestamp,
						"type": "chat_message",
						"user": parsed.author,
						"description": log_desc
					})
