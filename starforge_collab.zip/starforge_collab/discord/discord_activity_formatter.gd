@tool
class_name StarForgeDiscordActivityFormatter
extends RefCounted

## Utility to format Discord bridge events into workspace activity logs.

static func format_connection(bot_name: String) -> String:
	return "Bot Discord [%s] conectou-se com sucesso." % bot_name

static func format_received_message(author: String, text: String) -> String:
	return "Mensagem recebida de [%s]: \"%s\"" % [author, text]
