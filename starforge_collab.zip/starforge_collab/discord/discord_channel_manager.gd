@tool
class_name StarForgeDiscordChannelManager
extends RefCounted

## Manages Discord Channel IDs and provides configuration validations.

var primary_channel_id: int = 0
var logs_channel_id: int = 0

func _init(p_primary: int, p_logs: int = 0) -> void:
	primary_channel_id = p_primary
	logs_channel_id = p_logs

func is_valid() -> bool:
	return primary_channel_id > 0
