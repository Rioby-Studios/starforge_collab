@tool
class_name StarForgeDiscordMessageParser
extends RefCounted

## Utility to parse message data received from the Local Python Bot API.

static func parse_message(dict: Dictionary) -> Dictionary:
	return {
		"author": dict.get("author", "Desconhecido"),
		"text": dict.get("content", ""),
		"timestamp": dict.get("timestamp", 0)
	}
