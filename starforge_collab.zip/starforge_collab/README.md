# StarForge Collab 🚀

Plugin colaborativo profissional e minimalista para **Godot 4**, focado em integração Git, presença Discord, activity feeds, colaboração em equipe e automações de fluxo de trabalho (workflows).

A fundação do plugin foi desenhada sob altos padrões de engenharia de software para garantir escalabilidade, portabilidade e excelente performance, sem competir visualmente com o editor nativo.

---

## 📁 Estrutura de Pastas

A arquitetura de arquivos segue um padrão rigoroso de divisão de responsabilidades:

```
addons/
└── starforge_collab/
    ├── core/               # Núcleo da arquitetura (EventBus, Logger, ModuleManager, Module base class)
    │   ├── constants.gd
    │   ├── event_bus.gd
    │   ├── logger.gd
    │   ├── module_manager.gd
    │   └── starforge_module.gd
    ├── ui/                 # Elementos de Interface do Usuário construídos via código
    │   ├── dock_main/      # Painel de Dock acoplável na direita inferior
    │   │   └── dock_main.gd
    │   ├── tabs/           # Abas dinâmicas independentes
    │   │   ├── tab_activity.gd
    │   │   ├── tab_git.gd
    │   │   ├── tab_team.gd
    │   │   ├── tab_chat.gd
    │   │   └── tab_settings.gd
    │   └── components/     # Componentes gráficos reutilizáveis
    │       └── placeholder_panel.gd
    ├── settings/           # Gerenciamento de configurações integradas com a Godot
    │   └── settings_manager.gd
    ├── resources/          # Recursos extras (.tres, assets futuros)
    ├── icons/              # Ícones SVG customizados (futuros)
    ├── scenes/             # Cenas específicas (futuras)
    │
    ├── plugin.gd           # Entry point do plugin do editor
    ├── plugin.cfg          # Metadados do plugin
    └── README.md           # Documentação técnica do projeto
```

---

## 🏗️ Padrões de Arquitetura & Design

O StarForge Collab adota práticas avançadas de desenvolvimento de ferramentas para Godot 4:

1. **Comunicação por Event Bus**: Toda a comunicação entre módulos é realizada por meio de sinais tipados declarados na classe `StarForgeEventBus`. Isso elimina referências cruzadas ou acoplamento forte entre recursos.
2. **Gerenciador de Ciclo de Vida**: Cada recurso estende a classe base `StarForgeModule` e é gerenciado de forma transparente pelo `StarForgeModuleManager`.
3. **UI 100% Declarativa via Código**: Toda a interface gráfica é gerada via scripts GDScript programáticos. Isso previne corrupções de UIDs comuns em arquivos `.tscn` e elimina conflitos de mesclagem (merge conflicts) em controle de versão (Git).
4. **Respeito Absoluto ao Tema**: A UI não compete visualmente com a Godot. Ela obtém paletas de cores, fontes, tamanhos de fontes e ícones diretamente do tema ativo da Godot, adaptando-se instantaneamente quando o usuário muda o tema do editor (Light, Dark, Custom).

---

## 🛠️ Como Estender e Adicionar Novos Módulos

Para criar um novo módulo no futuro (ex: `StarForgeGitModule`):

1. Crie o arquivo GDScript correspondente na pasta adequada (ex: `core/git_module.gd`).
2. Faça a classe herdar de `StarForgeModule`.
3. Sobrescreva os métodos do ciclo de vida:

```gdscript
@tool
extends StarForgeModule

func _module_init(p_event_bus: StarForgeEventBus) -> void:
	super._module_init(p_event_bus)
	# Inscrever-se em sinais ou preparar conexões internas

func _module_ready() -> void:
	super._module_ready()
	# Módulo carregado e pronto para rodar

func _module_cleanup() -> void:
	# Importante: Desinscrever sinais e limpar referências aqui
	super._module_cleanup()
```

4. No script `plugin.gd`, adicione e instancie o módulo no `_enter_tree()`, registrando-o com `module_manager.register_module(novo_modulo)`.

---

## ⚙️ Configurações Integradas

O plugin se integra organicamente ao motor da Godot 4. As seguintes propriedades são geradas e podem ser visualizadas e gerenciadas através das **Configurações do Projeto (Project Settings)**:

* `starforge_collab/general/log_level`: Ajusta o console de debug (Debug, Info, Warn, Error).
* `starforge_collab/general/active_tab`: Memoriza a aba ativa do usuário, restaurando-a automaticamente entre reinicializações.
* `starforge_collab/general/enable_discord_rpc`: Liga/Desliga a atividade Discord RPC.
* `starforge_collab/general/git_auto_commit`: Opção para auto-commit inteligente de alterações de arquivos.
