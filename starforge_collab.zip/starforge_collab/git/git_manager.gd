@tool
class_name StarForgeGitManager
extends RefCounted

## Executes Git operations locally using OS.execute() in the project's directory context.
## Uses the "git -C <path>" pattern to operate cross-platform without shell wrappers.

var settings_manager: StarForgeSettingsManager = null

func _init(p_settings_manager: StarForgeSettingsManager = null) -> void:
	settings_manager = p_settings_manager

## Runs a git command with -C pointing to the globalized project path.
func _run_git(args: PackedStringArray) -> StarForgeGitOperationResult:
	var git_exe: String = "git"
	if settings_manager != null:
		var custom_path: String = settings_manager.get_setting(StarForgeConstants.SETTING_GIT_AUTO_COMMIT, "") # or use general git_path
		if ProjectSettings.has_setting("starforge_collab/general/git_path"):
			custom_path = ProjectSettings.get_setting("starforge_collab/general/git_path")
		if not custom_path.is_empty():
			git_exe = custom_path
			
	var project_path: String = ProjectSettings.globalize_path("res://")
	
	# Prepend -C <project_path> so git runs inside the Godot project folder
	var git_args: PackedStringArray = PackedStringArray(["-C", project_path])
	git_args.append_array(args)
	
	var output: Array = []
	var exit_code: int = OS.execute(git_exe, git_args, output, true, false)
	
	var output_str: String = ""
	if output.size() > 0:
		output_str = output[0]
		
	if exit_code == 0:
		return StarForgeGitOperationResult.new(true, output_str)
	else:
		var error_msg: String = "Comando falhou com código de saída %d." % exit_code
		if not output_str.is_empty():
			error_msg += " Detalhes: " + output_str.strip_edges()
		return StarForgeGitOperationResult.new(false, output_str, error_msg)

## Detects if the current project is situated inside an active Git repository.
func is_git_repository() -> bool:
	var result: StarForgeGitOperationResult = _run_git(PackedStringArray(["rev-parse", "--is-inside-work-tree"]))
	return result.success and result.output.strip_edges() == "true"

## Retrieves the name of the currently active Git branch.
func get_current_branch() -> String:
	var result: StarForgeGitOperationResult = _run_git(PackedStringArray(["rev-parse", "--abbrev-ref", "HEAD"]))
	if result.success:
		return result.output.strip_edges()
	return "Nenhuma"

## Checks the local status and returns classified staged, unstaged, and untracked file paths.
func get_git_status() -> Dictionary:
	var result: StarForgeGitOperationResult = _run_git(PackedStringArray(["status", "--porcelain"]))
	if result.success:
		return StarForgeGitStatusParser.parse(result.output)
	return {
		"staged": [],
		"unstaged": [],
		"untracked": []
	}

## Adds all changed files in the project to the Git staging index.
func git_add_all() -> StarForgeGitOperationResult:
	return _run_git(PackedStringArray(["add", "-A"]))

## Creates a new local commit with the given commit message.
func git_commit(message: String) -> StarForgeGitOperationResult:
	if message.strip_edges().is_empty():
		return StarForgeGitOperationResult.new(false, "", "Mensagem de commit vazia.")
	return _run_git(PackedStringArray(["commit", "-m", message]))

## Pushes the committed local changes to the remote branch repository.
func git_push() -> StarForgeGitOperationResult:
	var branch: String = get_current_branch()
	
	var username: String = ""
	var token: String = ""
	if settings_manager != null:
		username = settings_manager.get_setting(StarForgeSettingsManager.SETTING_GIT_USERNAME, "") as String
		token = settings_manager.get_secret("git_token", "")
		
	if not username.is_empty() and not token.is_empty():
		var remote_res: StarForgeGitOperationResult = _run_git(PackedStringArray(["remote", "get-url", "origin"]))
		if remote_res.success:
			var remote_url: String = remote_res.output.strip_edges()
			if remote_url.begins_with("https://"):
				var auth_url: String = _get_authenticated_url(remote_url, username, token)
				var res: StarForgeGitOperationResult = _run_git(PackedStringArray(["push", auth_url, branch]))
				res.output = _sanitize_output(res.output, token)
				res.error_message = _sanitize_output(res.error_message, token)
				return res
				
	return _run_git(PackedStringArray(["push", "origin", branch]))

## Pulls remote changes into the local working repository.
func git_pull() -> StarForgeGitOperationResult:
	var branch: String = get_current_branch()
	
	var username: String = ""
	var token: String = ""
	if settings_manager != null:
		username = settings_manager.get_setting(StarForgeSettingsManager.SETTING_GIT_USERNAME, "") as String
		token = settings_manager.get_secret("git_token", "")
		
	if not username.is_empty() and not token.is_empty():
		var remote_res: StarForgeGitOperationResult = _run_git(PackedStringArray(["remote", "get-url", "origin"]))
		if remote_res.success:
			var remote_url: String = remote_res.output.strip_edges()
			if remote_url.begins_with("https://"):
				var auth_url: String = _get_authenticated_url(remote_url, username, token)
				var res: StarForgeGitOperationResult = _run_git(PackedStringArray(["pull", auth_url, branch]))
				res.output = _sanitize_output(res.output, token)
				res.error_message = _sanitize_output(res.error_message, token)
				return res
				
	return _run_git(PackedStringArray(["pull", "origin", branch]))

## Fetches the latest updates from the remote repository tracking branches.
func git_fetch() -> StarForgeGitOperationResult:
	return _run_git(PackedStringArray(["fetch"]))

## Adds a single file path to the Git staging index.
func git_add_file(file_path: String) -> StarForgeGitOperationResult:
	return _run_git(PackedStringArray(["add", file_path]))

## Resets a single file path from the Git staging index (unstages it).
func git_reset_file(file_path: String) -> StarForgeGitOperationResult:
	return _run_git(PackedStringArray(["reset", "HEAD", file_path]))

# --- Private Secure Helpers ---

func _get_authenticated_url(remote_url: String, username: String, token: String) -> String:
	if not remote_url.begins_with("https://"):
		return remote_url
		
	var url_without_proto: String = remote_url.substr(8)
	var at_index: int = url_without_proto.find("@")
	if at_index != -1:
		url_without_proto = url_without_proto.substr(at_index + 1)
		
	var encoded_user: String = username.uri_encode()
	var encoded_token: String = token.uri_encode()
	
	return "https://%s:%s@%s" % [encoded_user, encoded_token, url_without_proto]

func _sanitize_output(text: String, token: String) -> String:
	if token.is_empty() or text.is_empty():
		return text
	return text.replace(token, "******")
