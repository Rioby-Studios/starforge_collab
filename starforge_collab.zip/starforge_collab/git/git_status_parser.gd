@tool
class_name StarForgeGitStatusParser
extends RefCounted

## Utility class to parse git status --porcelain terminal outputs.
## Categorizes modified resources into staged, unstaged, or untracked arrays.

static func parse(porcelain_output: String) -> Dictionary:
	var result: Dictionary = {
		"staged": [],
		"unstaged": [],
		"untracked": []
	}
	
	var lines: PackedStringArray = porcelain_output.split("\n", false)
	for line in lines:
		# A valid porcelain line has at least status prefix (2 chars), space, and file name.
		if line.length() < 4:
			continue
			
		var status_code: String = line.substr(0, 2)
		var file_path: String = line.substr(3).strip_edges()
		
		if status_code == "??":
			result["untracked"].append(file_path)
		else:
			var index_status: String = status_code.substr(0, 1)
			var worktree_status: String = status_code.substr(1, 1)
			
			# Staged if there is an active modification code in the index slot
			if index_status != " " and index_status != "?":
				result["staged"].append(file_path)
				
			# Unstaged if there is a modification code in the worktree slot
			if worktree_status != " " and worktree_status != "?":
				result["unstaged"].append(file_path)
				
	return result
