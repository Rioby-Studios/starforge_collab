@tool
class_name StarForgeGitUiController
extends RefCounted

## Intermediates operations between the Version Control GUI (tab_git.gd) and the GitManager.
## Fires event notifications and formats activity log events through the EventBus.

var git_manager: StarForgeGitManager = null
var event_bus: StarForgeEventBus = null

func _init(p_git_manager: StarForgeGitManager, p_event_bus: StarForgeEventBus) -> void:
	git_manager = p_git_manager
	event_bus = p_event_bus

## Fetches the current branch, repository status, and staged files list.
func refresh_status() -> Dictionary:
	if git_manager == null:
		return {
			"is_repository": false,
			"branch": "Nenhuma",
			"status": { "staged": [], "unstaged": [], "untracked": [] }
		}
	
	var is_repo: bool = git_manager.is_git_repository()
	var branch: String = "Nenhuma"
	var status: Dictionary = { "staged": [], "unstaged": [], "untracked": [] }
	
	if is_repo:
		branch = git_manager.get_current_branch()
		status = git_manager.get_git_status()
		
		if event_bus != null:
			event_bus.git_status_changed.emit(status)
		
	return {
		"is_repository": is_repo,
		"branch": branch,
		"status": status
	}

## Adds all local changes to staging.
func stage_all() -> bool:
	if git_manager == null:
		return false
	var res: StarForgeGitOperationResult = git_manager.git_add_all()
	return res.success

## Commits staged files and broadcasts activity logs.
func commit(message: String) -> StarForgeGitOperationResult:
	if git_manager == null:
		return StarForgeGitOperationResult.new(false, "", "GitManager não inicializado.")
		
	var res: StarForgeGitOperationResult = git_manager.git_commit(message)
	if res.success and event_bus != null:
		event_bus.git_operation_completed.emit("commit")
		
		var log_msg: String = StarForgeGitActivityFormatter.format_commit(message)
		event_bus.activity_created.emit({
			"timestamp": Time.get_unix_time_from_system() as int,
			"type": "git_commit",
			"user": "Você",
			"description": log_msg
		})
		
	return res

## Pushes committed revisions to remote and fires activity alerts.
func push() -> StarForgeGitOperationResult:
	if git_manager == null:
		return StarForgeGitOperationResult.new(false, "", "GitManager não inicializado.")
		
	var branch: String = git_manager.get_current_branch()
	var res: StarForgeGitOperationResult = git_manager.git_push()
	if res.success and event_bus != null:
		event_bus.git_operation_completed.emit("push")
		
		var log_msg: String = StarForgeGitActivityFormatter.format_push(branch)
		event_bus.activity_created.emit({
			"timestamp": Time.get_unix_time_from_system() as int,
			"type": "git_push",
			"user": "Você",
			"description": log_msg
		})
		
	return res

## Pulls from remote origin and updates workspace files.
func pull() -> StarForgeGitOperationResult:
	if git_manager == null:
		return StarForgeGitOperationResult.new(false, "", "GitManager não inicializado.")
		
	var branch: String = git_manager.get_current_branch()
	var res: StarForgeGitOperationResult = git_manager.git_pull()
	if res.success and event_bus != null:
		event_bus.git_operation_completed.emit("pull")
		
		var log_msg: String = StarForgeGitActivityFormatter.format_pull(branch)
		event_bus.activity_created.emit({
			"timestamp": Time.get_unix_time_from_system() as int,
			"type": "git_pull",
			"user": "Você",
			"description": log_msg
		})
		
	return res
