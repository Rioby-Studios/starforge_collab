@tool
class_name StarForgeGitActivityFormatter
extends RefCounted

## Utility to format local Git events into user-friendly Portuguese activity text logs.

static func format_commit(commit_message: String, author: String = "Você") -> String:
	return "%s realizou um commit: \"%s\"" % [author, commit_message]

static func format_push(branch: String, author: String = "Você") -> String:
	return "%s enviou atualizações (push) para a branch [%s]" % [author, branch]

static func format_pull(branch: String, author: String = "Você") -> String:
	return "%s baixou atualizações (pull) da branch [%s]" % [author, branch]
