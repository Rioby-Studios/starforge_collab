@tool
class_name StarForgeGitOperationResult
extends RefCounted

## Data container representing the outcome of an executed Git shell operation.

var success: bool = false
var output: String = ""
var error_message: String = ""

func _init(p_success: bool, p_output: String, p_error_message: String = "") -> void:
	success = p_success
	output = p_output
	error_message = p_error_message
