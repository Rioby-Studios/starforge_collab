@tool
class_name StarForgeActivityEvent
extends RefCounted

## Data container representing a collaborative event log (e.g., file changes, commits, chats).

var timestamp: int = 0
var type: String = ""
var user: String = ""
var description: String = ""

func _init(p_timestamp: int, p_type: String, p_user: String, p_description: String) -> void:
	timestamp = p_timestamp
	type = p_type
	user = p_user
	description = p_description

func to_dict() -> Dictionary:
	return {
		"timestamp": timestamp,
		"type": type,
		"user": user,
		"description": description
	}

static func from_dict(dict: Dictionary) -> StarForgeActivityEvent:
	return StarForgeActivityEvent.new(
		dict.get("timestamp", 0),
		dict.get("type", ""),
		dict.get("user", ""),
		dict.get("description", "")
	)
