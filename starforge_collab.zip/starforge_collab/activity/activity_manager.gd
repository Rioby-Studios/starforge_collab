@tool
class_name StarForgeActivityManager
extends RefCounted

## Manages history of collaborative activities in the workspace.
## Subscribes to the EventBus activity_created signal to populate its local log.

var event_bus: StarForgeEventBus = null
var activities: Array = [] # Array of StarForgeActivityEvent
const MAX_ACTIVITIES: int = 100

func _init(p_event_bus: StarForgeEventBus) -> void:
	event_bus = p_event_bus
	if event_bus != null:
		event_bus.activity_created.connect(_on_activity_created)

func _on_activity_created(data: Dictionary) -> void:
	var event: StarForgeActivityEvent = StarForgeActivityEvent.from_dict(data)
	
	# Insert at index 0 to show most recent events first
	activities.insert(0, event)
	
	# Keep memory footprint bounded
	if activities.size() > MAX_ACTIVITIES:
		activities.resize(MAX_ACTIVITIES)
		
	StarForgeLogger.debug("Activity logged: %s" % event.description, "ActivityManager")

## Returns a copy of the recorded activities log.
func get_activities() -> Array:
	return activities
