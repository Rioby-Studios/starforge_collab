@tool
class_name StarForgeFileWatcher
extends RefCounted

## Lightweight, highly optimized filesystem monitor utilizing Godot's native EditorFileSystem.
## Watches modifications, creations, and structure synchronizations in a 100% signal-driven manner.

var event_bus: StarForgeEventBus = null
var active: bool = false

func _init(p_event_bus: StarForgeEventBus) -> void:
	event_bus = p_event_bus

## Starts listening to native EditorFileSystem signals.
func start() -> void:
	if active:
		return
		
	var efs: EditorFileSystem = EditorInterface.get_resource_filesystem()
	if efs:
		efs.resources_changed.connect(_on_resources_changed)
		efs.resources_reimported.connect(_on_resources_reimported)
		efs.filesystem_changed.connect(_on_filesystem_changed)
		active = true
		StarForgeLogger.info("FileWatcher successfully connected to EditorFileSystem.", "FileWatcher")
	else:
		StarForgeLogger.error("Failed to connect to EditorFileSystem. FileWatcher inactive.", "FileWatcher")

## Disconnects filesystem listeners.
func stop() -> void:
	if not active:
		return
		
	var efs: EditorFileSystem = EditorInterface.get_resource_filesystem()
	if efs:
		if efs.resources_changed.is_connected(_on_resources_changed):
			efs.resources_changed.disconnect(_on_resources_changed)
		if efs.resources_reimported.is_connected(_on_resources_reimported):
			efs.resources_reimported.disconnect(_on_resources_reimported)
		if efs.filesystem_changed.is_connected(_on_filesystem_changed):
			efs.filesystem_changed.disconnect(_on_filesystem_changed)
		
	active = false
	StarForgeLogger.info("FileWatcher deactivated.", "FileWatcher")

## Triggered when an existing file is saved or modified inside the editor.
func _on_resources_changed(resources: PackedStringArray) -> void:
	if event_bus == null:
		return
		
	for res_path in resources:
		var ext: String = res_path.get_extension().to_lower()
		if ext == "gd" or ext == "tscn" or ext == "tres":
			var filename: String = res_path.get_file()
			var log_desc: String = "Você modificou o arquivo [%s]" % filename
			
			event_bus.activity_created.emit({
				"timestamp": Time.get_unix_time_from_system() as int,
				"type": "file_changed",
				"user": "Você",
				"description": log_desc
			})
			StarForgeLogger.debug("File modification detected: %s" % res_path, "FileWatcher")

## Triggered when a new resource is created, copied, or reimported.
func _on_resources_reimported(resources: PackedStringArray) -> void:
	if event_bus == null:
		return
		
	for res_path in resources:
		var ext: String = res_path.get_extension().to_lower()
		if ext == "gd" or ext == "tscn" or ext == "tres":
			var filename: String = res_path.get_file()
			var log_desc: String = "Arquivo importado/criado no projeto: [%s]" % filename
			
			event_bus.activity_created.emit({
				"timestamp": Time.get_unix_time_from_system() as int,
				"type": "file_created",
				"user": "Você",
				"description": log_desc
			})
			StarForgeLogger.debug("File creation/reimport detected: %s" % res_path, "FileWatcher")

## Triggered on structural updates, deletions, or directories movements.
func _on_filesystem_changed() -> void:
	if event_bus != null:
		# Structural logs in debug console
		StarForgeLogger.debug("Filesystem structure synchronized.", "FileWatcher")
